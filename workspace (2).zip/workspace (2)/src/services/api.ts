// Real backend API client. All ticketing / notification / discovery / settings
// pages talk to the FastAPI backend through this module — no mock data —
// EXCEPT when Demo Mode is ON (see demoMode.ts), in which case every call is
// served from an in-memory dataset so evaluators can browse realistic data
// without a running backend.
import { isDemoMode, demoStore } from './demoMode';

const TOKEN_KEY = 'ic_token';

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}
export function setToken(t: string) {
  localStorage.setItem(TOKEN_KEY, t);
}
export function clearToken() {
  localStorage.removeItem(TOKEN_KEY);
}

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

// Friendly, cross-platform message when the real backend is not reachable
// (e.g. nothing listening on :8000, or you launched Vite's *preview* server
// which has no /api proxy). Windows note: we always target 127.0.0.1 — using
// "localhost" can resolve to ::1 and fail when uvicorn binds IPv4 only.
export const BACKEND_DOWN_MSG =
  'Backend unreachable — nothing is listening on http://127.0.0.1:8000. ' +
  'Start it with `docker compose -f docker-compose.prebuilt.yml up -d` (or `python -m uvicorn app.main:app --host 127.0.0.1 --port 8000` in backend/), ' +
  'serve the app with `npm run dev` (NOT `vite preview`, which cannot proxy /api), ' +
  'or switch Demo Mode ON at login to explore with simulated data.';

async function realRequest<T>(path: string, options: RequestInit = {}): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> | undefined),
  };
  const token = getToken();
  if (token) headers['Authorization'] = `Bearer ${token}`;
  let res: Response;
  try {
    res = await fetch(`/api${path}`, { ...options, headers });
  } catch {
    // fetch() itself failed (ECONNREFUSED / network) — surface a clear hint.
    throw new ApiError(0, BACKEND_DOWN_MSG);
  }
  if (res.status === 204) return undefined as unknown as T;
  let body: any = null;
  try {
    body = await res.json();
  } catch {
    /* non-JSON body */
  }
  if (!res.ok) {
    const detail =
      (body && (body.detail?.msg ?? body.detail)) ?? `Request failed (${res.status})`;
    throw new ApiError(res.status, typeof detail === 'string' ? detail : JSON.stringify(detail));
  }
  return body as T;
}

// `request` is hoisted, so `api` may safely reference it before its definition.
export const api = {
  get: <T>(path: string) => request<T>(path),
  post: <T>(path: string, data?: unknown) =>
    request<T>(path, { method: 'POST', body: data === undefined ? undefined : JSON.stringify(data) }),
  patch: <T>(path: string, data?: unknown) =>
    request<T>(path, { method: 'PATCH', body: JSON.stringify(data) }),
  put: <T>(path: string, data?: unknown) =>
    request<T>(path, { method: 'PUT', body: JSON.stringify(data) }),
  del: <T>(path: string) => request<T>(path, { method: 'DELETE' }),
};

/** Download a binary endpoint as a real file (CSV proof-pack, attachments…).
 *  Works in both modes: Demo Mode answers through the simulated backend,
 *  real mode hits /api directly with the JWT header. */
export async function downloadFile(path: string, filename: string): Promise<void> {
  if (isDemoMode()) {
    // The demo interceptor returns JSON payloads; callers build the blob from them.
    throw new ApiError(0, 'DEMO_LOCAL');
  }
  const headers: Record<string, string> = {};
  const token = getToken();
  if (token) headers['Authorization'] = `Bearer ${token}`;
  const res = await fetch(`/api${path}`, { headers });
  if (!res.ok) throw new ApiError(res.status, 'Download failed');
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

/** Trigger a browser download from an in-memory string (used by the Value
 *  Engine proof pack in Demo Mode, where no server generates the file). */
export function downloadText(filename: string, text: string, mime = 'text/csv;charset=utf-8'): void {
  const blob = new Blob(['\ufeff' + text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

// ---------------------------------------------------------------------------
// Request router — THE single demo/real separation point.
// Demo Mode ON  → served entirely from the in-memory dataset (demoStore):
//                 no network call is made, so a missing backend can never
//                 break the demo experience (Kali or Windows).
// Demo Mode OFF → real FastAPI backend through the Vite dev proxy.
// ---------------------------------------------------------------------------
async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  if (isDemoMode()) return demoStore.handle<T>(options.method ?? 'GET', path, options.body);
  return realRequest<T>(path, options);
}

// ---------------------------------------------------------------------------
// Organizations (tenants) — real backend CRUD, platform_admin only
// ---------------------------------------------------------------------------
export interface BackendOrganization {
  id: number;
  name: string;
  tier: string;
  status: string;
  contact_email: string;
  contact_phone?: string | null;
  industry?: string | null;
  country?: string | null;
  member_count: number;
  asset_count: number;
  risk_score: number;
  compliance_score: number;
  monthly_revenue: number;
  created_at: string;
}

export interface OrganizationCreatePayload {
  name: string;
  tier: string;
  contact_email: string;
  contact_phone?: string;
  industry?: string;
  country?: string;
}

export const organizationsApi = {
  list: () => api.get<BackendOrganization[]>('/organizations/'),
  get: (id: number) => api.get<BackendOrganization>(`/organizations/${id}`),
  create: (data: OrganizationCreatePayload) =>
    api.post<BackendOrganization>('/organizations/', data),
  update: (id: number, data: Partial<OrganizationCreatePayload> & { status?: string }) =>
    api.patch<BackendOrganization>(`/organizations/${id}`, data),
};

// ---------------------------------------------------------------------------
// Auth
// ---------------------------------------------------------------------------
export interface BackendUser {
  id: number;
  email: string;
  name: string;
  role: string; // platform_admin | client_admin | client_user
  org_id: number | null;
  status: string;
}

export async function backendLogin(email: string, password: string): Promise<BackendUser> {
  const tok = await api.post<{ access_token: string; user?: BackendUser }>('/auth/login', { email, password });
  setToken(tok.access_token);
  // Newer backends return the user object with the token — use it directly.
  if (tok.user) return tok.user;
  try {
    return await api.get<BackendUser>('/auth/me');
  } catch {
    clearToken();
    throw new ApiError(401, 'Session token rejected by backend');
  }
}

// ---------------------------------------------------------------------------
// Advanced Ticketing
// ---------------------------------------------------------------------------
export interface AdvTicket {
  id: number;
  uid: string;
  org_id: number;
  title: string;
  description?: string;
  status: string;
  priority: string;
  category: string;
  source: string;
  assignee?: string | null;
  reporter?: string | null;
  tags: string[];
  asset?: string | null;
  vulnerability_ref?: string | null;
  ai_category?: string | null;
  ai_priority?: string | null;
  ai_confidence?: number | null;
  ai_reasoning: string[];
  ai_predicted_root_cause?: string | null;
  duplicate_of?: string | null;
  sla_state?: string | null;
  breach_prediction?: Record<string, any> | null;
  sla_response_minutes?: number | null;
  sla_resolution_minutes?: number | null;
  due_response_at?: string | null;
  due_resolve_at?: string | null;
  first_response_at?: string | null;
  resolved_at?: string | null;
  escalation_level: number;
  alert_id?: number | null;
  created_at: string;
  updated_at?: string | null;
}

export interface TicketEvidence {
  id: number;
  ticket_uid: string;
  kind: string;
  name: string;
  size_kb: number;
  sha256: string;
  collected_by: string;
  immutable: boolean;
  created_at: string;
}

export interface AuditEntry {
  seq: number;
  created_at: string;
  actor: string;
  action: string;
  detail?: string;
  prev_hash: string;
  entry_hash: string;
}

export interface Approval {
  id: number;
  ticket_uid: string;
  step: number;
  approver_role: string;
  status: string;
  note?: string;
  decided_by?: string | null;
  decided_at?: string | null;
}

export interface TenantRef {
  id: number;
  name: string;
}

export const ticketsApi = {
  list: (params: { org_id?: number; status?: string; priority?: string; q?: string } = {}) => {
    const qs = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => v !== undefined && v !== null && qs.set(k, String(v)));
    const s = qs.toString();
    return api.get<AdvTicket[]>(`/tickets${s ? `?${s}` : ''}`);
  },
  create: (data: {
    title: string;
    description?: string;
    priority: string;
    category: string;
    org_id?: number;
    assignee?: string;
    tags?: string[];
    asset?: string;
    vulnerability_ref?: string;
  }) => api.post<AdvTicket>('/tickets', data),
  tenants: () => api.get<TenantRef[]>('/tickets/meta/tenants'),
  update: (uid: string, data: Record<string, any>) => api.patch<AdvTicket>(`/tickets/${uid}`, data),
  evidence: (uid: string) => api.get<TicketEvidence[]>(`/tickets/${uid}/evidence`),
  addEvidence: (uid: string, data: { name: string; kind: string; content: string; file_b64?: string; mime_type?: string }) =>
    api.post<TicketEvidence>(`/tickets/${uid}/evidence`, data),
  downloadEvidence: async (uid: string, evidenceId: number, name: string) => {
    try {
      await downloadFile(`/tickets/${uid}/evidence/${evidenceId}/file`, name);
    } catch (ex: any) {
      // Demo Mode has no binary server route: replay the download through the simulated backend.
      if (isDemoMode()) await api.get<any>(`/tickets/${uid}/evidence/${evidenceId}/file`);
      else throw ex;
    }
  },
  audit: (uid: string) => api.get<AuditEntry[]>(`/tickets/${uid}/audit`),
  approvals: (uid: string) => api.get<Approval[]>(`/tickets/${uid}/approvals`),
  closureRequest: (uid: string, note: string) =>
    api.post<Approval>(`/tickets/${uid}/closure-request`, { note }),
  decide: (uid: string, approvalId: number, approve: boolean, note = '') =>
    api.post<Approval>(`/tickets/${uid}/approvals/${approvalId}/decide`, { approve, note }),
  workload: () => api.get<any[]>('/tickets/ops/workload'),
  runEscalations: () => api.post<any>('/tickets/ops/run-escalations'),
};

// ---------------------------------------------------------------------------
// Notification & Event Intelligence
// ---------------------------------------------------------------------------
export interface AlertRow {
  id: number;
  uid: string;
  org_id: number;
  title: string;
  description?: string;
  severity: string;
  source: string;
  resource?: string | null;
  correlated_count: number;
  storm_suppressed: boolean;
  acked_by?: string | null;
  acked_at?: string | null;
  ticket_uid?: string | null;
  created_at: string;
}

export interface NotifRule {
  id?: number;
  name: string;
  org_id?: number | null;
  enabled: boolean;
  conditions: Record<string, any>;
  channels: string[];
  recipients: string[];
  create_ticket: boolean;
  ticket_priority: string;
  escalate_after_minutes: number;
  quiet_hours?: Record<string, any> | null;
  created_at?: string;
}

export interface NotificationRow {
  id: number;
  org_id: number;
  alert_id?: number | null;
  rule_id?: number | null;
  channel: string;
  recipient: string;
  subject: string;
  body?: string;
  severity: string;
  status: string;
  attempts: number;
  last_error?: string | null;
  sent_at?: string | null;
  acked_by?: string | null;
  acked_at?: string | null;
  created_at: string;
}

export const alertsApi = {
  ingest: (data: {
    title: string;
    description?: string;
    severity: string;
    source: string;
    resource?: string;
    org_id?: number;
    raw_payload?: Record<string, any>;
  }) =>
    api.post<{ alert: AlertRow; pipeline: { notifications: any[]; ticket_created?: boolean; ticket_uid?: string | null } }>('/alerts', data),
  list: (org_id?: number) =>
    api.get<AlertRow[]>(`/alerts${org_id ? `?org_id=${org_id}` : ''}`),
  ack: (id: number) => api.post(`/alerts/${id}/ack`),
  rules: () => api.get<NotifRule[]>('/notification-rules'),
  createRule: (rule: Omit<NotifRule, 'id' | 'created_at'>) =>
    api.post<NotifRule>('/notification-rules', rule),
  updateRule: (id: number, patch: Partial<NotifRule>) =>
    api.patch<NotifRule>(`/notification-rules/${id}`, patch),
  deleteRule: (id: number) => api.del(`/notification-rules/${id}`),
  notifications: (statusF?: string) =>
    api.get<NotificationRow[]>(`/notifications${statusF ? `?status=${statusF}` : ''}`),
  ackNotification: (id: number) => api.post(`/notifications/${id}/ack`),
  retryDeadLetters: () => api.post<any>('/notifications/retry-dead-letters'),
  analytics: () => api.get<Record<string, any>>('/notifications/analytics'),
};

// ---------------------------------------------------------------------------
// Playbooks
// ---------------------------------------------------------------------------
export interface PlaybookStep {
  name: string;
  action: string;
  params: Record<string, any>;
}
export interface Playbook {
  id: number;
  name: string;
  description: string;
  category: string;
  steps: PlaybookStep[];
  enabled: boolean;
}
export interface PlaybookRunLog {
  ok: boolean;
  log: { step: number; name: string; action: string; status: string; detail: string }[];
}

export const playbooksApi = {
  list: () => api.get<Playbook[]>('/playbooks'),
  save: (pb: Omit<Playbook, 'id'> & { id?: number }) =>
    pb.id ? api.put<Playbook>(`/playbooks/${pb.id}`, pb) : api.post<Playbook>('/playbooks', pb),
  remove: (id: number) => api.del(`/playbooks/${id}`),
  run: (id: number) => api.post<PlaybookRunLog>(`/playbooks/${id}/run`),
};

// ---------------------------------------------------------------------------
// Discovery / SNMP
// ---------------------------------------------------------------------------
export interface SnmpCredential {
  id?: number;
  name: string;
  version: string;
  community?: string | null;
  username?: string | null;
  auth_protocol?: string | null;
  auth_passphrase?: string | null;
  priv_protocol?: string | null;
  priv_passphrase?: string | null;
  port: number;
  org_id?: number | null;
  created_at?: string;
}

export interface ScanRow {
  id: number;
  org_id: number;
  network_cidr: string;
  status: string;
  credential_ids: number[];
  total_hosts: number;
  discovered: number;
  snmp_matched: number;
  started_at?: string | null;
  finished_at?: string | null;
  created_by: string;
  created_at: string;
}

export interface DiscoveredDevice {
  id: number;
  scan_id: number;
  org_id: number;
  ip: string;
  mac?: string | null;
  hostname?: string | null;
  os_guess?: string | null;
  device_type?: string | null;
  open_ports: number[];
  snmp_match: boolean;
  sys_desc?: string | null;
  imported: boolean;
  created_at: string;
}

export const discoveryApi = {
  credentials: () => api.get<SnmpCredential[]>('/snmp-credentials'),
  createCredential: (c: Omit<SnmpCredential, 'id' | 'created_at'>) =>
    api.post<SnmpCredential>('/snmp-credentials', c),
  deleteCredential: (id: number) => api.del(`/snmp-credentials/${id}`),
  scans: () => api.get<ScanRow[]>('/scans'),
  startScan: (network_cidr: string, credential_ids: number[], org_id?: number) =>
    api.post<ScanRow>('/scans', { network_cidr, credential_ids, org_id }),
  scanStatus: (id: number) => api.get<ScanRow>(`/scans/${id}`),
  scanDevices: (id: number) => api.get<DiscoveredDevice[]>(`/scans/${id}/devices`),
  devices: () => api.get<DiscoveredDevice[]>('/devices'),
  importDevice: (id: number) => api.post(`/devices/${id}/import`),
  engineStatus: () => api.get<{ nmap_available: boolean; mode: string }>('/engine-status'),
};

// ---------------------------------------------------------------------------
// Platform settings
// ---------------------------------------------------------------------------
export interface SettingsOverview {
  tenants: { id: number; name: string; tier: string; status: string }[];
  rule_count: number;
  global_rule_count: number;
  user_count: number;
  delivery_mode: string;
}

export interface SystemSettings {
  auto_ticketing: boolean;
  sla_escalations: boolean;
  email_enabled: boolean;
  sms_enabled: boolean;
  webhook_enabled: boolean;
  quiet_hours: boolean;
  escalation_email: string;
  webhook_url: string;
}

export interface DemoAccountRequest {
  email: string;
  password: string;
  org_name: string;
  service_ids: string[] | null; // null => all 16 services + Advanced Ticketing
  trial_days: number;           // default 30
}

export const settingsApi = {
  overview: () => api.get<SettingsOverview>('/settings/overview'),
  get: () => api.get<SystemSettings>('/settings/system'),
  update: (patch: Partial<SystemSettings>) =>
    api.put<SystemSettings>('/settings/system', patch),
  seedDemoTenant: (orgName = 'Damanecash') =>
    api.post<any>(`/settings/seed-demo-tenant?org_name=${encodeURIComponent(orgName)}`),
  // Real creation in the database of a demo/trial account for a real user,
  // with configurable service entitlements and a trial window (default 30d).
  createDemoAccount: (req: DemoAccountRequest) =>
    api.post<any>('/settings/seed-demo-tenant', req as any),
};

// ---------------------------------------------------------------------------
// Demo mode — pushes realistic sample ALERTS through the REAL ingest pipeline
// (/api/alerts). The backend then does everything for real: correlation,
// rule matching, notification dispatch and automatic ticket creation. No mock
// data is injected into the UI; this only simulates an upstream feed.
// ---------------------------------------------------------------------------
const SAMPLE_EVENTS = [
  { title: 'Brute-force SSH attempts from 45.132.87.10', severity: 'high', source: 'wazuh', resource: 'fw-edge-01', description: '23 failed authentications in 60s against sshd on DMZ gateway.' },
  { title: 'TLS certificate expires in 6 days', severity: 'medium', source: 'monitor', resource: 'web-prod-02', description: 'Certificate for portal.acme-corp.com reaches expiry on Friday.' },
  { title: 'Critical vulnerability CVE-2026-31337 detected', severity: 'critical', source: 'vuln-scanner', resource: 'db-primary-01', description: 'Unpatched OpenSSL remote-code-execution flaw found during authenticated scan.' },
  { title: 'CPU sustained above 92% for 15 minutes', severity: 'medium', source: 'monitor', resource: 'app-node-03', description: 'Load average 12.4 on 4 vCPU host; suspected runaway worker process.' },
  { title: 'Unauthorized privilege escalation attempt', severity: 'critical', source: 'suricata', resource: 'dc-core-sw-01', description: 'TGP-3 payload observed targeting management VLAN from user workstation.' },
  { title: 'Backup job failed with checksum mismatch', severity: 'low', source: 'backup-agent', resource: 'nas-backup-01', description: 'Nightly snapshot verification failed on volume /vault/archive.' },
];

export async function pushDemoEvents(orgId?: number): Promise<{ alerts: number; tickets: string[] }> {
  const createdTickets: string[] = [];
  let alerts = 0;
  for (const ev of SAMPLE_EVENTS) {
    try {
      const res = await alertsApi.ingest({ ...ev, org_id: orgId });
      alerts += 1;
      const uid = res.pipeline?.ticket_uid;
      if (uid) createdTickets.push(uid);
    } catch { /* tenant may not exist yet — keep going */ }
  }
  return { alerts, tickets: createdTickets };
}

// ---------------------------------------------------------------------------
// Project Manager — real backend /api/projects, Demo Mode served by demoStore.
// Two structures on purpose (see backend routers/projects.py):
//   kind 'internal' → OUR delivery projects with a client (platform side);
//   kind 'client'   → the client's own projects (his side, incl. his clients).
// ---------------------------------------------------------------------------
export interface ProjectMilestone { id: number; title: string; done: boolean }
export interface Project {
  id: number; org_id: number; name: string; description: string;
  kind: 'internal' | 'client'; status: string; priority: string;
  manager_email: string; ticket_category: string;
  time_spent_seconds: number; timer_running: boolean;
  sla_hours: number; sla_status: string; due_at?: string | null;
  created_by: string; created_at?: string;
  milestones?: ProjectMilestone[]; progress_pct?: number;
}
export interface ProjectDetail extends Project {
  milestones: ProjectMilestone[]; progress_pct: number;
  tickets: { total: number; open: number; items: { uid: string; title: string; status: string; priority: string }[] };
}
/** Project attachment — file (image / PDF / config / txt) or pasted text note. */
export interface ProjectAttachment {
  id: number; project_id: number; name: string; kind: string;
  content?: string | null; mime_type?: string | null; size_kb: number;
  sha256: string; uploaded_by: string; created_at?: string; has_file: boolean;
}
/** Read a browser File as base64 (without the data-URL prefix). */
export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result).split(',')[1] ?? '');
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}
export const projectsApi = {
  list: (orgId?: number) => api.get<Project[]>(`/projects/${orgId ? `?org_id=${orgId}` : ''}`),
  get: (id: number) => api.get<ProjectDetail>(`/projects/${id}`),
  create: (data: Partial<Project> & { name: string; org_id?: number; milestones?: string[] }) =>
    api.post<Project>('/projects/', data),
  update: (id: number, data: Partial<Project>) => api.patch<Project>(`/projects/${id}`, data),
  remove: (id: number) => api.del<void>(`/projects/${id}`),
  /** Project configuration (SLA, risk threshold, budget, auto-close, notifications). */
  config: (id: number, patch?: Record<string, any>) =>
    patch ? api.put<any>(`/projects/${id}/config`, patch) : api.get<any>(`/projects/${id}/config`),
  timer: (id: number, action: 'start' | 'pause' | 'resume' | 'stop') =>
    api.post<Project>(`/projects/${id}/timer/${action}`),
  addMilestone: (id: number, title: string) =>
    api.post<Project>(`/projects/${id}/milestones?title=${encodeURIComponent(title)}`),
  toggleMilestone: (mid: number, done: boolean) =>
    api.patch<{ id: number; done: boolean }>('/projects/milestones/' + mid, { done }),
  attachments: (id: number) => api.get<ProjectAttachment[]>(`/projects/${id}/attachments`),
  addAttachment: (id: number, data: { name: string; kind: string; content?: string; file_b64?: string; mime_type?: string }) =>
    api.post<ProjectAttachment>(`/projects/${id}/attachments`, data),
  removeAttachment: (id: number, attId: number) =>
    api.del<void>(`/projects/${id}/attachments/${attId}`),
  /** Download a project attachment. Works in both modes (demo replays the
   *  simulated backend which returns {b64, mime} and builds the blob locally). */
  downloadAttachment: async (id: number, attId: number, name: string) => {
    if (isDemoMode()) {
      const r = await api.get<{ b64: string; mime: string }>(`/projects/${id}/attachments/${attId}/file`);
      const bin = atob(r.b64 ?? '');
      const bytes = Uint8Array.from(bin, c => c.charCodeAt(0));
      const url = URL.createObjectURL(new Blob([bytes], { type: r.mime || 'application/octet-stream' }));
      const a = document.createElement('a');
      a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 4000);
      return;
    }
    await downloadFile(`/projects/${id}/attachments/${attId}/file`, name);
  },
};

// ---------------------------------------------------------------------------
// Value Engine — the 6 "show the money" mechanics (receipt, red line, risk
// cost, before/after, maturity, proof pack). Real backend: /api/value.
// Demo mode: computed from the SAME demo tickets/alerts → always synchronized.
// ---------------------------------------------------------------------------
export interface ValuePayload {
  period: string;
  receipt: {
    hash: string; hours_saved: number; labor_saved_usd: number;
    downtime_avoided_usd: number; total_usd: number; tickets_total: number;
    tickets_resolved: number; auto_closed: number; ai_triaged: number;
    alerts_total: number; alerts_suppressed: number;
  };
  red_line: { avg_mttr_min: number; baseline_mttr_min: number; improvement_pct: number; false_positive_pct: number };
  risk_cost: { exposure_usd: number; critical_open: number; high_open: number; sla_breaches: number;
               per_action: { close_p1: number; close_p2: number; fix_breach: number } };
  maturity: { score: number; benchmark_sector_avg: number;
              components: { alert_coverage: number; automation_rate: number; ai_triage_rate: number; sla_compliance: number } };
  generated_at: string;
}

export const valueApi = {
  get: (period?: string, orgId?: number) => {
    const qs = new URLSearchParams();
    if (period) qs.set('period', period);
    if (orgId) qs.set('org_id', String(orgId));
    return api.get<ValuePayload>(`/value?${qs.toString()}`);
  },
  receipt: (period?: string, orgId?: number) => {
    const qs = new URLSearchParams();
    if (period) qs.set('period', period);
    if (orgId) qs.set('org_id', String(orgId));
    return api.get<ValuePayload['receipt'] & { period: string; maturity: number }>(`/value/receipt?${qs.toString()}`);
  },
  /** Mechanic 6 — exportable "Proof Pack" CSV. Real mode downloads the server
   *  file; Demo Mode builds the identical CSV client-side from the payload so
   *  the numbers always match what the screen shows. */
  proofPackCsv: async (v: ValuePayload): Promise<void> => {
    const filename = `infracentra-proof-pack-${v.period}.csv`;
    try {
      await downloadFile(`/value/proof-pack?format=csv`, filename);
    } catch (e: any) {
      if (e?.message !== 'DEMO_LOCAL') throw e;
      const rows: string[][] = [
        ['Infracentra — Proof Pack', v.period], [],
        ['VALUE RECEIPT'],
        ['Hours saved', String(v.receipt.hours_saved)],
        ['Labor saved (USD)', String(v.receipt.labor_saved_usd)],
        ['Downtime avoided (USD)', String(v.receipt.downtime_avoided_usd)],
        ['TOTAL VALUE (USD)', String(v.receipt.total_usd)],
        ['Tickets resolved / total', `${v.receipt.tickets_resolved} / ${v.receipt.tickets_total}`],
        ['Auto-closed by playbooks', String(v.receipt.auto_closed)],
        ['AI-triaged tickets', String(v.receipt.ai_triaged)],
        ['Alerts suppressed', String(v.receipt.alerts_suppressed)],
        ['Receipt hash', v.receipt.hash], [],
        ['RED LINE (before → after)'],
        ['MTTR baseline (min)', String(v.red_line.baseline_mttr_min)],
        ['MTTR now (min)', String(v.red_line.avg_mttr_min)],
        ['Improvement (%)', String(v.red_line.improvement_pct)],
        ['False positives (%)', String(v.red_line.false_positive_pct)], [],
        ['RISK COST (open exposure)'],
        ['Exposure (USD)', String(v.risk_cost.exposure_usd)],
        ['Critical open', String(v.risk_cost.critical_open)],
        ['High open', String(v.risk_cost.high_open)],
        ['SLA breaches', String(v.risk_cost.sla_breaches)],
        ['Value per P1 closed (USD)', String(v.risk_cost.per_action.close_p1)], [],
        ['MATURITY'],
        ['Score', String(v.maturity.score)],
        ['Sector benchmark', String(v.maturity.benchmark_sector_avg)],
        ['Alert coverage', String(v.maturity.components.alert_coverage)],
        ['Automation rate', String(v.maturity.components.automation_rate)],
        ['AI triage rate', String(v.maturity.components.ai_triage_rate)],
        ['SLA compliance', String(v.maturity.components.sla_compliance)],
      ];
      downloadText(filename, rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\r\n'));
    }
  },
};
