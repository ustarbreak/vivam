// ---------------------------------------------------------------------------
// DEMO MODE — fully client-side simulated backend.
//
// When the visitor picks "Demo Mode" on the login page (localStorage key
// `ic_demo_mode` = '1'), every API call made through src/services/api.ts is
// answered HERE, from an in-memory dataset that mimics the FastAPI backend:
// Advanced Ticketing, Alerts / Notification Rules / Notifications, Playbooks,
// Discovery and Settings. No network request is ever sent, so the demo works
// identically on Kali and Windows even when Docker/Postgres/the API are not
// running — and it can never pollute real data.
//
// Turning Demo Mode OFF instantly restores 100% real-backend behaviour.
// ---------------------------------------------------------------------------

import {
  demoTenants, demoDevices, demoAlertSeeds, demoTicketSeeds, demoPlaybookSeeds, demoTechnicians,
  computeDemoStats, isDemoWorldInstalled, markDemoWorldInstalled, DEMO_WORLD_VERSION,
} from '../data/demoWorld';
import { demoProjects } from '../data/demoProjects';
import { partners, partnerProgramStats } from '../data/partnerWorld';

// ---------------------------------------------------------------------------
// Project Manager — in-memory store mirroring backend/app/routers/projects.py.
// Scope rules are identical: platform_admin sees/creates 'internal' projects
// (assigned to an organization, never without one); client users see ALL
// projects of their own org ('internal' = with us, 'client' = their own).
// ---------------------------------------------------------------------------
let projectSeq = 300;
let milestoneSeq = 100;
const projectsStore = JSON.parse(JSON.stringify(demoProjects)) as any[];

function demoSession(): { role?: string; orgId?: string | null; email?: string } {
  try { return JSON.parse(localStorage.getItem('ic_demo_session') ?? '{}'); } catch { return {}; }
}
function callerOrgId(): number | null {
  const s = demoSession();
  if (s.role === 'platform_admin') return null;
  const m = /^org-dw-(\d+)$/.exec(String(s.orgId ?? ''));
  if (m) return Number(m[1]);
  // Fallback: resolve the tenant from the logged-in email's Moroccan domain.
  const domOrg: Record<string, number> = { 'damanecash.ma': 1, 'valorissystem.ma': 2, 'vivalissalaf.ma': 3 };
  return domOrg[String(s.email ?? '').split('@')[1]?.toLowerCase()] ?? 1;
}
function serializeProject(p: any) {
  let slaStatus = 'none';
  if (p.sla_hours) {
    const remainingH = p.sla_hours - Math.round(p.time_spent_seconds / 3600);
    slaStatus = p.status === 'completed' ? 'met' : remainingH < 0 ? 'breached' : remainingH < 24 ? 'at_risk' : 'on_track';
  }
  const done = p.milestones.filter((m: any) => m.done).length;
  return { ...p, sla_status: slaStatus, progress_pct: p.milestones.length ? Math.round(100 * done / p.milestones.length) : 0 };
}

export function isDemoMode(): boolean {
  return localStorage.getItem('ic_demo_mode') === '1';
}

export function setDemoMode(on: boolean) {
  localStorage.setItem('ic_demo_mode', on ? '1' : '0');
  if (on && !isDemoWorldInstalled()) installDemoWorld();
  window.dispatchEvent(new Event('demo-mode-changed'));
}

// Auto-materialise the coherent demo world the first time Demo Mode is used,
// so every engine/dashboard is synchronized even before clicking the button.
function installDemoWorld() {
  markDemoWorldInstalled();
}

const now = Date.now();
const iso = (minutesAgo: number) => new Date(now - minutesAgo * 60_000).toISOString();

// -- demo tenants ------------------------------------------------------------
interface DemoOrg { id: number; name: string; tier: string; ticketing: boolean }
const orgs: DemoOrg[] = demoTenants.map(t => ({ ...t }));

let ticketSeq = 1000;
let alertSeq = 1;
let notifSeq = 1;
let ruleSeq = 100;

const mkTicket = (t: Partial<any> & { title: string }) => ({
  id: ticketSeq++,
  uid: `TCK-${String(ticketSeq).padStart(5, '0')}`,
  org_id: 1,
  description: '',
  status: 'open',
  priority: 'p3',
  category: 'incident',
  source: 'manual',
  assignee: null,
  reporter: 'demo@infracentra.io',
  tags: [] as string[],
  asset: null,
  vulnerability_ref: null,
  ai_category: null,
  ai_priority: null,
  ai_confidence: null,
  ai_reasoning: [] as string[],
  ai_predicted_root_cause: null,
  duplicate_of: null,
  sla_state: 'on_track',
  breach_prediction: null,
  sla_response_minutes: 30,
  sla_resolution_minutes: 240,
  due_response_at: iso(-20),
  due_resolve_at: iso(-180),
  first_response_at: null,
  resolved_at: null,
  escalation_level: 0,
  alert_id: null,
  created_at: iso(60),
  updated_at: iso(30),
  ...t,
});

// Seed tickets — materialised from the single Demo World dataset so that
// ticket assets, alert resources and monitored devices always agree.
const tickets: any[] = demoTicketSeeds.map(s => mkTicket({
  uid: s.uid,
  title: s.title,
  description: s.description,
  status: s.status, priority: s.priority, category: s.category, source: s.source,
  assignee: s.assignee, tags: s.tags, asset: s.asset, org_id: s.orgId,
  sla_state: s.sla_state, created_at: iso(s.minutesAgo), updated_at: iso(Math.max(0, s.minutesAgo - 15)),
  escalation_level: s.status === 'escalated' ? 2 : 0,
  alert_id: (() => { const a = demoAlertSeeds.findIndex(x => x.uid === s.alertUid); return a >= 0 ? a + 1 : null; })(),
  resolved_at: s.resolvedMinutesAgo !== undefined ? iso(s.resolvedMinutesAgo) : null,
  first_response_at: s.resolvedMinutesAgo !== undefined ? iso(s.minutesAgo - 5) : null,
  ...(s.vulnerability_ref ? { vulnerability_ref: s.vulnerability_ref } : {}),
  ...(s.ai_confidence !== undefined ? {
    ai_category: s.category, ai_priority: s.priority, ai_confidence: s.ai_confidence,
    ai_reasoning: ['Correlated signals from Demo World alert engine'],
  } : {}),
}));
ticketSeq = 1012; // next manual ticket keeps the sequence coherent

const evidenceByUid: Record<string, any[]> = {};
// Project attachments store (demo mirror of the backend ProjectAttachment table).
const projectAttachments: Record<number, any[]> = {};
let attSeq = 1;
/** Byte length of a base64 string without decoding it. */
function atobSize(b64: string): number { return Math.floor(b64.length * 3 / 4); }
/** Deterministic FNV-1a hex "hash" for demo evidence/attachment integrity lines. */
function demoHash(s: string): string {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; }
  return ('00000000' + h.toString(16)).slice(-8).repeat(4);
}
const auditByUid: Record<string, any[]> = {};
const approvalsByUid: Record<string, any[]> = {};

const pushEvidence = (uid: string, name: string, kind: string, sizeKb: number) => {
  (evidenceByUid[uid] ??= []).push({
    id: Math.floor(Math.random() * 1e6), ticket_uid: uid, kind, name,
    size_kb: sizeKb, sha256: Array.from({ length: 16 }, () => '0123456789abcdef'[Math.floor(Math.random() * 16)]).join('') + '…',
    collected_by: 'demo-collector', immutable: true, created_at: iso(40),
  });
};
const pushAudit = (uid: string, actor: string, action: string, detail: string, minutesAgo: number) => {
  const list = (auditByUid[uid] ??= []);
  const prev = list.length ? list[list.length - 1].entry_hash : 'GENESIS';
  list.push({
    seq: list.length + 1, created_at: iso(minutesAgo), actor, action, detail,
    prev_hash: prev, entry_hash: 'sha256:' + btoa(uid + action + list.length).replace(/=/g, ''),
  });
};

tickets.forEach(t => {
  pushEvidence(t.uid, `${t.asset ?? 'host'}_syslog_last24h.txt`, 'log', 128 + (t.id % 7) * 34);
  pushEvidence(t.uid, 'network_capture.pcap', 'pcap', 512);
  pushAudit(t.uid, 'system', 'created', `Ticket opened via ${t.source}`, 60);
  pushAudit(t.uid, 'ai-engine', 'triage', `AI classified as ${t.ai_category ?? t.category}/${t.ai_priority ?? t.priority}`, 59);
  if (t.assignee) pushAudit(t.uid, 'dispatcher', 'assigned', `Assigned to ${t.assignee}`, 55);
  if (['resolved', 'closed'].includes(t.status)) pushAudit(t.uid, t.assignee ?? 'agent', 'resolved', 'Work completed, evidence attached', 20);
});
approvalsByUid[tickets[0].uid] = [{
  id: 1, ticket_uid: tickets[0].uid, step: 1, approver_role: 'security_lead',
  status: 'pending', note: 'Closure requires lead sign-off for P1 incidents.', decided_by: null, decided_at: null,
}];

// -- alerts / rules / notifications ------------------------------------------
// Alerts are materialised from the Demo World seeds; ticket_uid is resolved by
// matching the alertUid link declared on the ticket seed => perfect sync.
const ticketsByAlertUid: Record<string, string> = {};
demoTicketSeeds.forEach(s => { if (s.alertUid) ticketsByAlertUid[s.alertUid] = s.uid; });

const alerts: any[] = demoAlertSeeds.map((s, i) => ({
  id: i + 1, uid: s.uid, org_id: s.orgId, title: s.title, severity: s.severity, source: s.source,
  resource: s.hostname, correlated_count: s.correlated, storm_suppressed: s.correlated > 10,
  acked_by: null, acked_at: null, ticket_uid: ticketsByAlertUid[s.uid] ?? null,
  created_at: iso(s.minutesAgo), description: s.description,
}));
alertSeq = demoAlertSeeds.length + 1;

const rules: any[] = [
  { id: 1, name: 'P1 auto-escalation', org_id: null, enabled: true, conditions: { severity: ['critical'] }, channels: ['email', 'sms', 'webhook'], recipients: ['soc-leads@infracentra.io'], create_ticket: true, ticket_priority: 'p1', escalate_after_minutes: 15, quiet_hours: null, created_at: iso(9000) },
  { id: 2, name: 'High sev → email on-call', org_id: null, enabled: true, conditions: { severity: ['high'] }, channels: ['email'], recipients: ['oncall@infracentra.io'], create_ticket: true, ticket_priority: 'p2', escalate_after_minutes: 30, quiet_hours: null, created_at: iso(8000) },
  { id: 3, name: 'Vuln scanner digest (daily)', org_id: null, enabled: false, conditions: { source: ['vuln-scanner'] }, channels: ['email'], recipients: ['cto@damanecash.ma'], create_ticket: false, ticket_priority: 'p3', escalate_after_minutes: 0, quiet_hours: { start: '21:00', end: '07:00' }, created_at: iso(7000) },
];

const notifications: any[] = [
  { id: notifSeq++, org_id: 1, alert_id: 1, rule_id: 1, channel: 'email', recipient: 'soc-leads@infracentra.io', subject: '[CRITICAL] Ransomware precursor on NAS-01', body: 'Immediate containment recommended.', severity: 'critical', status: 'sent', attempts: 1, last_error: null, sent_at: iso(45), acked_by: null, acked_at: null, created_at: iso(45) },
  { id: notifSeq++, org_id: 1, alert_id: 1, rule_id: 1, channel: 'sms', recipient: '+33 6 12 34 56 78', subject: 'P1 incident escalated', body: 'TCK-01001 awaiting containment.', severity: 'critical', status: 'sent', attempts: 1, last_error: null, sent_at: iso(45), acked_by: null, acked_at: null, created_at: iso(45) },
  { id: notifSeq++, org_id: 1, alert_id: 2, rule_id: 2, channel: 'email', recipient: 'oncall@infracentra.io', subject: '[HIGH] SSH brute-force fw-edge-01', body: 'Source blocked at edge after acknowledgment.', severity: 'high', status: 'acked', attempts: 1, last_error: null, sent_at: iso(90), acked_by: 'ops@damanecash.ma', acked_at: iso(80), created_at: iso(90) },
  { id: notifSeq++, org_id: 2, alert_id: 3, rule_id: 1, channel: 'webhook', recipient: 'https://hooks.valorissystem.ma/soc', subject: 'Privilege escalation attempt', body: 'Downstream SIEM returned HTTP 503 twice.', severity: 'critical', status: 'dead_letter', attempts: 3, last_error: 'Webhook endpoint unreachable (503)', sent_at: null, acked_by: null, acked_at: null, created_at: iso(150) },
];

// -- playbooks ----------------------------------------------------------------
const playbooks: any[] = demoPlaybookSeeds.map((p, i) => ({
  id: i + 1, ...p, steps: p.steps.map(s => ({ ...s, params: {} })),
}));

// -- discovery / settings -------------------------------------------------------
const snmpCredentials: any[] = [
  { id: 1, name: 'Edge switches v2c', version: '2c', community: 'public-ro', username: null, auth_protocol: null, auth_passphrase: null, priv_protocol: null, priv_passphrase: null, port: 161, org_id: null, created_at: iso(20000) },
];
const scans: any[] = [];
// Discovery inventory mirrors the Demo World devices so MonitoredDevices,
// NetworkPage and Statistics always show the SAME hostnames/IPs/status.
const discoveredDevices: any[] = demoDevices.map((d, i) => ({
  id: i + 1, scan_id: 0, org_id: d.orgId, ip: d.ip, mac: `aa:bb:cc:${String(d.orgId).padStart(2, '0')}:${d.id.slice(-2).replace(/[^0-9a-f]/gi, '0').padStart(2, '0')}:ff`,
  hostname: d.hostname, os_guess: d.os, device_type: d.type, open_ports: [22, 443],
  snmp_match: ['firewall', 'switch', 'router'].includes(d.type), sys_desc: `Demo World managed ${d.type}`,
  imported: true, status: d.status, location: d.location, created_at: iso(10000 - i * 60),
}));
let scanSeq = 1;
let devSeq = discoveredDevices.length + 1;

// One completed baseline scan so the Scans tab is not empty on first visit.
scans.push({ id: scanSeq++, org_id: 1, network_cidr: '10.0.0.0/16', status: 'completed', credential_ids: [1], total_hosts: 254, discovered: demoDevices.filter(d => d.orgId === 1).length, snmp_matched: demoDevices.filter(d => d.orgId === 1 && ['firewall', 'switch', 'router'].includes(d.type)).length, started_at: iso(10000), finished_at: iso(9990), created_by: 'demo@infracentra.io', created_at: iso(10000) });
discoveredDevices.forEach(d => { if (d.orgId === 1) d.scan_id = 1; });

const systemSettings = {
  auto_ticketing: true, sla_escalations: true, email_enabled: true, sms_enabled: true,
  webhook_enabled: true, quiet_hours: false, escalation_email: 'escalations@infracentra.io',
  webhook_url: 'https://hooks.infracentra.io/soc',
};

// -- tiny helpers ---------------------------------------------------------------
const delay = <T>(value: T, ms = 120): Promise<T> =>
  new Promise(res => setTimeout(() => res(value), ms));

const parseBody = (body?: BodyInit | null): any => {
  try { return body ? JSON.parse(String(body)) : {}; } catch { return {}; }
};

const splitPath = (path: string) => {
  const [p, qs] = path.split('?');
  return { parts: p.replace(/^\/+|\/+$/g, '').split('/'), query: new URLSearchParams(qs ?? '') };
};

const httpErr = (status: number, msg: string) => {
  const e: any = new Error(msg);
  e.demoStatus = status;
  return e;
};

// Simulated AI triage for tickets created in demo mode.
const fakeAi = (title: string, priority: string, category: string) => {
  const t = title.toLowerCase();
  let conf = 0.75;
  let prio = priority;
  const reasoning: string[] = [`Title keywords matched (${category})`];
  if (/ransom|malware|exploit|breach/.test(t)) { prio = 'p1'; conf = 0.95; reasoning.push('Malware/exploitation vocabulary'); }
  else if (/brute|unauthorized|privilege/.test(t)) { prio = 'p2'; conf = 0.87; reasoning.push('Intrusion attempt pattern'); }
  else if (/patch|cve|vulnerab/.test(t)) { reasoning.push('Vulnerability vocabulary'); }
  else { reasoning.push('No strong security signal — kept submitted priority'); }
  return { ai_category: category, ai_priority: prio, ai_confidence: conf, ai_reasoning: reasoning, ai_predicted_root_cause: /cpu|memory|disk/.test(t) ? 'Resource saturation' : null };
};

// ---------------------------------------------------------------------------
// The mock router used by api.ts when Demo Mode is ON.
// ---------------------------------------------------------------------------
export const demoStore = {
  async handle<T>(method: string, path: string, body?: BodyInit | null): Promise<T> {
    const { parts, query } = splitPath(path);
    const root = parts[0];
    const b = parseBody(body);

    // ---- Tickets ----
    if (root === 'tickets') {
      if (method === 'GET' && parts.length === 1) {
        let list = [...tickets].sort((a, z) => z.created_at.localeCompare(a.created_at));
        if (query.get('status')) list = list.filter(t => t.status === query.get('status'));
        if (query.get('priority')) list = list.filter(t => t.priority === query.get('priority'));
        if (query.get('org_id')) list = list.filter(t => String(t.org_id) === query.get('org_id'));
        const q = (query.get('q') ?? '').toLowerCase();
        if (q) list = list.filter(t => t.title.toLowerCase().includes(q) || t.uid.toLowerCase().includes(q));
        return delay(list as any) as unknown as T;
      }
      if (method === 'POST' && parts.length === 1) {
        const ai = fakeAi(b.title ?? '', b.priority ?? 'p3', b.category ?? 'incident');
        const t = mkTicket({ ...b, source: 'portal', reporter: 'demo@infracentra.io', created_at: iso(0), updated_at: iso(0), due_response_at: iso(-30), due_resolve_at: iso(-240), ...ai });
        tickets.unshift(t);
        pushAudit(t.uid, 'demo-user', 'created', 'Created from demo console', 0);
        pushAudit(t.uid, 'ai-engine', 'triage', `AI classified as ${t.ai_category}/${t.ai_priority} (conf ${(t.ai_confidence * 100).toFixed(0)}%)`, 0);
        return delay(t as any) as unknown as T;
      }
      if (method === 'GET' && parts[1] === 'meta' && parts[2] === 'tenants') return delay(orgs as any) as unknown as T;
      if (method === 'GET' && parts[1] === 'ops' && parts[2] === 'workload') {
        const byAssignee: Record<string, number> = {};
        tickets.filter(t => !['resolved', 'closed'].includes(t.status)).forEach(t => { byAssignee[t.assignee ?? 'Unassigned'] = (byAssignee[t.assignee ?? 'Unassigned'] ?? 0) + 1; });
        return delay(Object.entries(byAssignee).map(([assignee, open]) => ({ assignee, open })) as any) as unknown as T;
      }
      if (method === 'POST' && parts[1] === 'ops' && parts[2] === 'run-escalations') {
        tickets.forEach(t => { if (t.sla_state === 'breached' && !['resolved', 'closed'].includes(t.status)) { t.escalation_level += 1; pushAudit(t.uid, 'sla-engine', 'escalated', `SLA breached → level ${t.escalation_level}`, 0); } });
        return delay({ escalated: tickets.filter(t => t.escalation_level > 0).length } as any) as unknown as T;
      }
      const uid = parts[1];
      if (!uid) throw httpErr(404, 'Demo: unknown tickets route');
      const tk = tickets.find(t => t.uid === uid);
      if (!tk && ['GET', 'PATCH'].includes(method) && parts.length >= 2 && parts[1] !== 'meta' && parts[1] !== 'ops') throw httpErr(404, `Demo: ticket ${uid} not found`);
      if (method === 'GET' && parts[2] === 'evidence') return delay((evidenceByUid[uid] ?? []) as any) as unknown as T;
      if (method === 'GET' && parts[2] === 'evidence' && parts[4] === 'file') {
        // Demo download of an uploaded attachment: reconstruct the blob from the staged base64.
        const ev = (evidenceByUid[uid] ?? []).find((x: any) => x.id === Number(parts[3]));
        if (!ev || !(ev as any).has_file) throw httpErr(404, 'Demo: attachment not found');
        const bin = atob(String((ev as any)._b64 ?? ''));
        const bytes = Uint8Array.from(bin, c => c.charCodeAt(0));
        const url = URL.createObjectURL(new Blob([bytes], { type: (ev as any).mime_type || 'application/octet-stream' }));
        const a = document.createElement('a');
        a.href = url; a.download = ev.name; document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 4000);
        return delay({ ok: true } as any) as unknown as T;
      }
      if (method === 'POST' && parts[2] === 'evidence') {
        const isFile = Boolean(b.file_b64);
        const approxBytes = isFile ? Math.floor(String(b.file_b64).length * 3 / 4) : String(b.content ?? '').length;
        const ev = { id: Math.floor(Math.random() * 1e6), ticket_uid: uid, kind: b.kind ?? 'log', name: b.name ?? 'artifact', size_kb: Math.round(approxBytes / 1024) + 1, sha256: 'sha256:' + btoa(String(b.content ?? b.file_b64 ?? '')).slice(0, 24), collected_by: 'demo-user', immutable: true, created_at: iso(0), has_file: isFile, mime_type: b.mime_type ?? null };
        if (isFile) (ev as any)._b64 = String(b.file_b64);
        (evidenceByUid[uid] ??= []).push(ev);
        pushAudit(uid, 'demo-user', 'evidence', `Evidence added: ${ev.name}`, 0);
        return delay(ev as any) as unknown as T;
      }
      if (method === 'GET' && parts[2] === 'audit') return delay([...(auditByUid[uid] ?? [])].reverse() as any) as unknown as T;
      if (method === 'GET' && parts[2] === 'approvals') return delay((approvalsByUid[uid] ?? []) as any) as unknown as T;
      if (method === 'POST' && parts[2] === 'closure-request') {
        const ap = { id: Math.floor(Math.random() * 1e6), ticket_uid: uid, step: (approvalsByUid[uid]?.length ?? 0) + 1, approver_role: 'security_lead', status: 'pending', note: b.note ?? '', decided_by: null, decided_at: null };
        (approvalsByUid[uid] ??= []).push(ap);
        pushAudit(uid, 'demo-user', 'closure_requested', ap.note, 0);
        return delay(ap as any) as unknown as T;
      }
      if (method === 'POST' && parts[2] === 'approvals' && parts[4] === 'decide') {
        const ap = (approvalsByUid[uid] ?? []).find((x: any) => x.id === Number(parts[3]));
        if (!ap) throw httpErr(404, 'Demo: approval step not found');
        ap.status = b.approve ? 'approved' : 'rejected';
        ap.decided_by = 'demo-lead@infracentra.io';
        ap.decided_at = iso(0);
        if (b.approve && tk) { tk.status = 'closed'; tk.resolved_at = tk.resolved_at ?? iso(0); }
        pushAudit(uid, 'demo-lead', ap.status, ap.note ?? '', 0);
        return delay(ap as any) as unknown as T;
      }
      if (method === 'PATCH') {
        Object.assign(tk, b, { updated_at: iso(0) });
        pushAudit(uid, 'demo-user', 'updated', Object.keys(b).join(', '), 0);
        return delay(tk as any) as unknown as T;
      }
    }

    // ---- Alerts / notification rules / notifications ----
    if (root === 'alerts') {
      if (method === 'POST' && parts.length === 1) {
        const a = { id: alertSeq++, uid: `ALR-${String(alertSeq).padStart(4, '0')}`, org_id: b.org_id ?? 1, title: b.title ?? 'Untitled event', description: b.description ?? '', severity: b.severity ?? 'medium', source: b.source ?? 'api', resource: b.resource ?? null, correlated_count: 1, storm_suppressed: false, acked_by: null, acked_at: null, ticket_uid: null, created_at: iso(0) };
        alerts.unshift(a);
        const pipeline: any = { notifications: [] as any[] };
        for (const r of rules.filter(x => x.enabled)) {
          const sevOk = !r.conditions.severity || r.conditions.severity.includes(a.severity);
          const srcOk = !r.conditions.source || r.conditions.source.includes(a.source);
          if (!sevOk || !srcOk) continue;
          for (const ch of r.channels) {
            const n = { id: notifSeq++, org_id: a.org_id, alert_id: a.id, rule_id: r.id, channel: ch, recipient: r.recipients[0] ?? 'ops@infracentra.io', subject: `[${a.severity.toUpperCase()}] ${a.title}`, body: a.description, severity: a.severity, status: 'sent', attempts: 1, last_error: null, sent_at: iso(0), acked_by: null, acked_at: null, created_at: iso(0) };
            notifications.unshift(n);
            pipeline.notifications.push(n);
          }
          if (r.create_ticket) {
            const ai = fakeAi(a.title, r.ticket_priority, 'incident');
            const t = mkTicket({ title: a.title, description: a.description, priority: r.ticket_priority, category: 'incident', source: 'alert_engine', org_id: a.org_id, asset: a.resource, alert_id: a.id, created_at: iso(0), ...ai });
            tickets.unshift(t);
            a.ticket_uid = t.uid;
            pushAudit(t.uid, 'alert-engine', 'created', `Auto-opened from ${a.uid}`, 0);
            pipeline.ticket_created = true;
            pipeline.ticket_uid = t.uid;
          }
        }
        return delay({ alert: a, pipeline } as any) as unknown as T;
      }
      if (method === 'GET' && parts.length === 1) {
        let list = [...alerts].sort((a, z) => z.created_at.localeCompare(a.created_at));
        if (query.get('org_id')) list = list.filter(x => String(x.org_id) === query.get('org_id'));
        return delay(list as any) as unknown as T;
      }
      if (method === 'POST' && parts[2] === 'ack') {
        const a = alerts.find(x => x.id === Number(parts[1]));
        if (a) { a.acked_by = 'demo@infracentra.io'; a.acked_at = iso(0); }
        return delay(a as any) as unknown as T;
      }
    }
    if (root === 'notification-rules') {
      if (method === 'GET') return delay(rules as any) as unknown as T;
      if (method === 'POST') {
        const r = { id: ruleSeq++, created_at: iso(0), ...b };
        rules.push(r);
        return delay(r as any) as unknown as T;
      }
      const id = Number(parts[1]);
      const idx = rules.findIndex(r => r.id === id);
      if (method === 'PATCH' && idx >= 0) { rules[idx] = { ...rules[idx], ...b }; return delay(rules[idx] as any) as unknown as T; }
      if (method === 'DELETE' && idx >= 0) { rules.splice(idx, 1); return delay(undefined as any) as unknown as T; }
    }
    if (root === 'notifications') {
      if (method === 'GET' && parts.length === 1) {
        let list = [...notifications].sort((a, z) => z.created_at.localeCompare(a.created_at));
        if (query.get('status')) list = list.filter(n => n.status === query.get('status'));
        const lim = Number(query.get('limit') ?? 0);
        if (lim > 0) list = list.slice(0, lim);
        // Bell component expects { items: [...] }; other pages expect the raw array.
        return delay(lim > 0 ? ({ items: list } as any) : (list as any)) as unknown as T;
      }
      if (method === 'POST' && parts[1] === 'retry-failed') {
        let n = 0;
        notifications.forEach(x => { if (x.status === 'dead_letter') { x.status = 'queued'; x.last_error = null; n++; } });
        return delay({ requeued: n } as any) as unknown as T;
      }
      if (method === 'GET' && parts[1] === 'analytics') {
        const byStatus: Record<string, number> = {};
        notifications.forEach(n => { byStatus[n.status] = (byStatus[n.status] ?? 0) + 1; });
        const byChannel: Record<string, number> = {};
        notifications.forEach(n => { byChannel[n.channel] = (byChannel[n.channel] ?? 0) + 1; });
        return delay({ total: notifications.length, by_status: byStatus, by_channel: byChannel, avg_time_to_ack_minutes: 12, dead_letters: byStatus.dead_letter ?? 0 } as any) as unknown as T;
      }
      if (method === 'POST' && parts[1] === 'retry-dead-letters') {
        let n = 0;
        notifications.forEach(x => { if (x.status === 'dead_letter') { x.status = 'queued'; x.attempts += 0; x.last_error = null; n++; } });
        return delay({ requeued: n } as any) as unknown as T;
      }
      if (method === 'POST' && parts[2] === 'ack') {
        const nt = notifications.find(x => x.id === Number(parts[1]));
        if (nt) { nt.status = 'acked'; nt.acked_by = 'demo@infracentra.io'; nt.acked_at = iso(0); }
        return delay(nt as any) as unknown as T;
      }
    }

    // ---- Playbooks ----
    if (root === 'playbooks') {
      if (method === 'GET') return delay(playbooks as any) as unknown as T;
      if (method === 'POST') { const pb = { id: Math.max(...playbooks.map(p => p.id), 0) + 1, ...b }; playbooks.push(pb); return delay(pb as any) as unknown as T; }
      const id = Number(parts[1]);
      const idx = playbooks.findIndex(p => p.id === id);
      if (method === 'PUT' && idx >= 0) { playbooks[idx] = { ...playbooks[idx], ...b, id }; return delay(playbooks[idx] as any) as unknown as T; }
      if (method === 'DELETE' && idx >= 0) { playbooks.splice(idx, 1); return delay(undefined as any) as unknown as T; }
      if (method === 'POST' && parts[2] === 'run') {
        const pb = playbooks[idx];
        const log = (pb?.steps ?? []).map((s, i) => ({ step: i + 1, name: s.name, action: s.action, status: 'success', detail: 'Simulated execution (demo mode)' }));
        return delay({ ok: true, log } as any) as unknown as T;
      }
    }

    // ---- Discovery / SNMP ----
    if (root === 'snmp-credentials') {
      if (method === 'GET') return delay(snmpCredentials as any) as unknown as T;
      if (method === 'POST') { const c = { id: snmpCredentials.length + 1, created_at: iso(0), ...b }; snmpCredentials.push(c); return delay(c as any) as unknown as T; }
      if (method === 'DELETE') { const i = snmpCredentials.findIndex(c => c.id === Number(parts[1])); if (i >= 0) snmpCredentials.splice(i, 1); return delay(undefined as any) as unknown as T; }
    }
    if (root === 'scans') {
      if (method === 'GET' && parts.length === 1) return delay(scans as any) as unknown as T;
      if (method === 'POST' && parts.length === 1) {
        const s = { id: scanSeq++, org_id: b.org_id ?? 1, network_cidr: b.network_cidr ?? '10.0.0.0/24', status: 'completed', credential_ids: b.credential_ids ?? [], total_hosts: 254, discovered: 18, snmp_matched: 6, started_at: iso(1), finished_at: iso(0), created_by: 'demo@infracentra.io', created_at: iso(1) };
        scans.unshift(s);
        for (let i = 1; i <= 8; i++) {
          discoveredDevices.push({ id: devSeq++, scan_id: s.id, org_id: s.org_id, ip: `10.0.0.${i * 7}`, mac: `aa:bb:cc:00:${String(i).padStart(2, '0')}:ff`, hostname: `demo-host-${i}`, os_guess: i % 3 === 0 ? 'Linux 6.x' : 'Windows Server 2022', device_type: i % 2 ? 'server' : 'network', open_ports: [22, 443].slice(0, (i % 2) + 1), snmp_match: i % 2 === 0, sys_desc: 'Demo simulated device', imported: false, created_at: iso(0) });
        }
        return delay(s as any) as unknown as T;
      }
      if (method === 'GET' && parts[2] === 'devices') return delay(discoveredDevices.filter(d => d.scan_id === Number(parts[1])) as any) as unknown as T;
      if (method === 'GET') return delay(scans.find(s => s.id === Number(parts[1])) as any) as unknown as T;
    }
    if (root === 'devices') {
      if (method === 'GET') return delay(discoveredDevices as any) as unknown as T;
      if (method === 'POST' && parts[2] === 'import') { const d = discoveredDevices.find(x => x.id === Number(parts[1])); if (d) d.imported = true; return delay(d as any) as unknown as T; }
    }
    if (root === 'engine-status') return delay({ nmap_available: false, mode: 'demo-simulated' } as any) as unknown as T;

    // ---- Project Manager (mirrors backend routers/projects.py) ----
    if (root === 'projects') {
      const isPlatform = callerOrgId() === null && demoSession().role === 'platform_admin';
      if (method === 'GET' && parts.length === 1) {
        let list = isPlatform
          ? projectsStore.filter(p => p.kind === 'internal')
          : projectsStore.filter(p => p.org_id === callerOrgId());
        if (query.get('kind')) list = list.filter(p => p.kind === query.get('kind'));
        if (query.get('org_id') && isPlatform) list = projectsStore.filter(p => String(p.org_id) === query.get('org_id'));
        return delay(list.map(serializeProject) as any) as unknown as T;
      }
      if (method === 'POST' && parts.length === 1) {
        const org = isPlatform ? Number(b.org_id ?? 0) : callerOrgId()!;
        if (isPlatform && !org) throw httpErr(400, 'Platform admins must assign the project to an organization');
        // Runbook auto-generation: POST /projects/runbooks-from-doc { name, description, doc }
        if (query.get('runbook') || b.doc !== undefined) {
          const steps = String(b.doc ?? b.description ?? '')
            .split(/\r?\n/).map((s: string) => s.trim()).filter(Boolean)
            .slice(0, 8)
            .map((title: string, i: number) => ({ id: milestoneSeq++, title: title.replace(/^[-*#\d.\s]+/, '').slice(0, 90) || `Step ${i + 1}`, done: false }));
          const rb = {
            id: projectSeq++, org_id: org, name: b.name ?? 'Runbook généré',
            description: b.description ?? 'Runbook auto-créé depuis la documentation IT fournie.',
            kind: isPlatform ? 'internal' : 'client', status: 'planned', priority: 'low',
            manager_email: b.manager_email ?? '', ticket_category: `runbook-${String(b.name ?? 'rb').toLowerCase().replace(/\s+/g, '-')}`,
            sla_hours: Number(b.sla_hours ?? 24), time_spent_seconds: 0, timer_running: false,
            generated_from_doc: true, created_by: demoSession().email ?? 'demo@infracentra.io',
            milestones: steps.length ? steps : [{ id: milestoneSeq++, title: 'Préparation', done: false }, { id: milestoneSeq++, title: 'Exécution', done: false }, { id: milestoneSeq++, title: 'Validation & clôture', done: false }],
          };
          projectsStore.unshift(rb);
          return delay(serializeProject(rb) as any) as unknown as T;
        }
        const p = {
          id: projectSeq++, org_id: org, name: b.name ?? 'Nouveau projet', description: b.description ?? '',
          kind: isPlatform ? 'internal' : (b.kind === 'client' ? 'client' : 'client'),
          status: 'planned', priority: b.priority ?? 'medium', manager_email: b.manager_email ?? '',
          ticket_category: b.ticket_category || String(b.name ?? 'projet').toLowerCase().replace(/\s+/g, '-'),
          sla_hours: Number(b.sla_hours ?? 0), time_spent_seconds: 0, timer_running: false,
          created_by: demoSession().email ?? 'demo@infracentra.io',
          milestones: (b.milestones ?? []).map((t: string) => ({ id: milestoneSeq++, title: t, done: false })),
        };
        projectsStore.unshift(p);
        return delay(serializeProject(p) as any) as unknown as T;
      }
      const pid = Number(parts[1]);
      const pr = projectsStore.find(x => x.id === pid);
      if (!pr) throw httpErr(404, 'Demo: project not found');
      if (!isPlatform && pr.org_id !== callerOrgId()) throw httpErr(403, 'Cross-tenant access denied');
      if (parts[2] === 'timer') {
        const action = parts[3];
        if (action === 'start' || action === 'resume') pr.timer_running = true;
        else if (action === 'pause') { if (pr.timer_running) { pr.time_spent_seconds += 3600; pr.timer_running = false; } }
        else if (action === 'stop') { if (pr.timer_running) pr.time_spent_seconds += 3600; pr.timer_running = false; }
        return delay(serializeProject(pr) as any) as unknown as T;
      }
      if (parts[2] === 'milestones' && method === 'POST') {
        pr.milestones.push({ id: milestoneSeq++, title: query.get('title') ?? b.title ?? 'Jalon', done: false });
        return delay(serializeProject(pr) as any) as unknown as T;
      }
      // PATCH /projects/milestones/{mid} — toggle a milestone (backend parity)
      if (parts[1] === 'milestones' && method === 'PATCH') {
        const mid = Number(parts[2]);
        for (const p0 of projectsStore) {
          const m = p0.milestones.find((x: any) => x.id === mid);
          if (m) {
            if (!isPlatform && p0.org_id !== callerOrgId()) throw httpErr(403, 'Cross-tenant access denied');
            m.done = b.done ?? !m.done;
            return delay({ id: m.id, done: m.done } as any) as unknown as T;
          }
        }
        throw httpErr(404, 'Demo: milestone not found');
      }
      // ---- attachments (mirrors backend routers/projects.py) ----
      if (parts[2] === 'attachments') {
        const store = (projectAttachments[pid] ??= []);
        const attOut = (a: any) => ({ ...a, has_file: !!a.file_b64 });
        if (method === 'GET') return delay(store.map(attOut) as any) as unknown as T;
        if (method === 'POST') {
          const payloadForHash = b.file_b64 || String(b.content ?? '');
          const att = {
            id: attSeq++, project_id: pid, name: b.name ?? 'document', kind: b.kind ?? 'txt',
            content: b.content ?? null, mime_type: b.mime_type ?? null,
            size_kb: Math.max(1, Math.round(((b.file_b64 ? atobSize(b.file_b64) : String(b.content ?? '').length) / 1024))),
            sha256: demoHash(payloadForHash), uploaded_by: demoSession().email ?? 'demo@infracentra.io',
            created_at: new Date().toISOString(), file_b64: b.file_b64 ?? null,
          };
          store.unshift(att);
          return delay(attOut(att) as any) as unknown as T;
        }
        const attId = Number(parts[3]);
        const idx = store.findIndex(a => a.id === attId);
        if (idx === -1) throw httpErr(404, 'Demo: attachment not found');
        if (method === 'DELETE') { store.splice(idx, 1); return delay(undefined as any) as unknown as T; }
        if (method === 'GET' && parts[4] === 'file') return delay({ b64: store[idx].file_b64, mime: store[idx].mime_type } as any) as unknown as T;
      }
      // GET/PUT /projects/{pid}/config — per-project settings (backend parity via PATCH fallback)
      if (parts[2] === 'config') {
        pr.config = pr.config ?? { sla_hours: pr.sla_hours, delay_alert_days: 3, risk_threshold: 70, budget_eur: 0, auto_close_tickets: true, notify_manager: true };
        if (method === 'PUT') { Object.assign(pr.config, b); return delay(pr.config as any) as unknown as T; }
        return delay(pr.config as any) as unknown as T;
      }
      if (method === 'DELETE') {
        const idx = projectsStore.findIndex(x => x.id === pid);
        if (idx >= 0) projectsStore.splice(idx, 1);
        delete projectAttachments[pid];
        return delay(undefined as any) as unknown as T;
      }
      if (method === 'GET') {
        const linked = tickets.filter(t => pr.ticket_category && (t.category === pr.ticket_category || (t.tags ?? []).includes(pr.ticket_category)));
        const openT = linked.filter(t => !['resolved', 'closed'].includes(t.status));
        return delay({ ...serializeProject(pr), tickets: { total: linked.length, open: openT.length, items: linked.slice(0, 50).map(t => ({ uid: t.uid, title: t.title, status: t.status, priority: t.priority })) } } as any) as unknown as T;
      }
      if (method === 'PATCH') { Object.assign(pr, b); return delay(serializeProject(pr) as any) as unknown as T; }
    }

    // ---- Settings ----
    if (root === 'settings') {
      if (parts[1] === 'overview') {
        const st = computeDemoStats();
        return delay({ tenants: orgs.map(o => ({ ...o, status: 'active' })), rule_count: rules.length, global_rule_count: rules.filter(r => !r.org_id).length, user_count: st.technicians, delivery_mode: 'console-only (demo)', demo_world: DEMO_WORLD_VERSION, stats: st } as any) as unknown as T;
      }
      if (parts[1] === 'system') {
        if (method === 'PUT') { Object.assign(systemSettings, b); return delay(systemSettings as any) as unknown as T; }
        return delay(systemSettings as any) as unknown as T;
      }
      if (parts[1] === 'seed-demo-tenant') return delay({ seeded: true, demo: true, message: 'Demo mode already contains sample tenants, tickets, alerts and rules.' } as any) as unknown as T;
      // "Push Demo Dataset" — one-click synchronised preprod-style dataset.
      if (parts[1] === 'push-demo-world' && method === 'POST') {
        markDemoWorldInstalled();
        const st = computeDemoStats();
        return delay({ ok: true, version: DEMO_WORLD_VERSION, engines: ['ticketing', 'notifications', 'playbooks', 'discovery', 'reports', 'partners'], stats: st } as any) as unknown as T;
      }
    }

    // ---- Value Engine (6 money-showing mechanics) — mirrors routers/value.py ----
    // Derived from the SAME demo tickets/alerts arrays so every number on the
    // Overview, ROI report and Proof Pack is synchronized with the rest of the
    // demo world.
    if (root === 'value') {
      const vt = [...tickets];
      const va = [...alerts];
      const resolved = vt.filter(t => ['resolved', 'closed'].includes(t.status));
      const autoClosed = resolved.filter(t => ['alert', 'api', 'discovery'].includes(t.source));
      const aiTriaged = vt.filter(t => t.triaged_at || t.ai_category);
      const acked = va.filter(a => a.acked_at);
      const suppressed = va.filter(a => a.storm_suppressed);
      const minutesSaved = autoClosed.length * 25 + aiTriaged.length * 12 + acked.length * 8 + suppressed.length * 5;
      const hoursSaved = Math.round((minutesSaved / 60) * 10) / 10;
      const laborUsd = Math.round(hoursSaved * 45 * 100) / 100;
      const avgMttr = 47;
      const avoidedH = Math.round(Math.max(240 - avgMttr, 0) * resolved.length / 60 * 10) / 10;
      const downtimeUsd = Math.round(avoidedH * 800 * 100) / 100;
      const totalUsd = Math.round((laborUsd + downtimeUsd) * 100) / 100;
      const critOpen = vt.filter(t => t.priority === 'p1' && !['resolved', 'closed'].includes(t.status)).length;
      const highOpen = vt.filter(t => t.priority === 'p2' && !['resolved', 'closed'].includes(t.status)).length;
      const breaches = vt.filter(t => t.sla_state === 'breached' && !['resolved', 'closed'].includes(t.status)).length;
      const exposure = critOpen * 25000 + highOpen * 8000 + breaches * 3500;
      const cov = Math.min(100, Math.round(acked.length / Math.max(va.length, 1) * 1000) / 10);
      const autoRate = Math.round(autoClosed.length / Math.max(vt.length, 1) * 1000) / 10;
      const triageRate = Math.round(aiTriaged.length / Math.max(vt.length, 1) * 1000) / 10;
      const slaRate = Math.round((vt.length - breaches) / Math.max(vt.length, 1) * 1000) / 10;
      const maturity = Math.round((cov * .2 + autoRate * .3 + triageRate * .2 + slaRate * .3) * 10) / 10;
      const payload: any = {
        period: new Date().toISOString().slice(0, 7),
        receipt: { hash: 'demo-' + (totalUsd | 0).toString(16), hours_saved: hoursSaved, labor_saved_usd: laborUsd,
          downtime_avoided_usd: downtimeUsd, total_usd: totalUsd, tickets_total: vt.length, tickets_resolved: resolved.length,
          auto_closed: autoClosed.length, ai_triaged: aiTriaged.length, alerts_total: va.length, alerts_suppressed: suppressed.length },
        red_line: { avg_mttr_min: avgMttr, baseline_mttr_min: 240, improvement_pct: Math.round((240 - avgMttr) / 240 * 1000) / 10, false_positive_pct: 8.4 },
        risk_cost: { exposure_usd: exposure, critical_open: critOpen, high_open: highOpen, sla_breaches: breaches,
          per_action: { close_p1: 25000, close_p2: 8000, fix_breach: 3500 } },
        maturity: { score: maturity, benchmark_sector_avg: 54, components: { alert_coverage: cov, automation_rate: autoRate, ai_triage_rate: triageRate, sla_compliance: slaRate } },
        generated_at: new Date().toISOString(),
      };
      if (parts[1] === 'receipt') return delay({ period: payload.period, ...payload.receipt, maturity: payload.maturity.score } as any) as unknown as T;
      if (parts[1] === 'proof-pack') return delay(payload as any) as unknown as T;
      return delay(payload as any) as unknown as T;
    }

    // ---- Partner Program (MSP white-label) — mirrors backend routers/partners.py ----
    // Demo data source of truth: src/data/partnerWorld.ts. The partner session
    // is scoped to its own partner id; cross-partner access returns 403 exactly
    // like the real backend would.
    if (root === 'partners') {
      const s = demoSession();
      const callerPartnerId = s.role === 'partner_admin' ? String(s.orgId ?? '') : null;
      const isPlatform = s.role === 'platform_admin';
      if (!isPlatform && !callerPartnerId) throw httpErr(403, 'Partners routes require a partner or platform-admin session');

      if (method === 'GET' && parts.length === 1) {
        // Platform admin sees every partner; a partner only ever sees itself.
        return delay((isPlatform ? partners : partners.filter(p => p.id === callerPartnerId)) as any) as unknown as T;
      }
      if (method === 'GET' && parts[1] === 'stats') {
        if (!isPlatform) throw httpErr(403, 'Program-wide stats are reserved for Infracentra platform admins');
        return delay(partnerProgramStats() as any) as unknown as T;
      }
      const pid = parts[1];
      const partner = partners.find(p => p.id === pid);
      if (!partner) throw httpErr(404, `Demo: partner ${pid} not found`);
      if (callerPartnerId && pid !== callerPartnerId) throw httpErr(403, 'Cross-partner access denied');

      if (method === 'GET' && parts.length === 2) return delay(partner as any) as unknown as T;
      if (method === 'GET' && parts[2] === 'license') return delay(partner.license as any) as unknown as T;
      if (method === 'GET' && parts[2] === 'branding') return delay(partner.branding as any) as unknown as T;
      if (method === 'PUT' && parts[2] === 'branding') {
        Object.assign(partner.branding, b);
        if (b.dns_status === 'verified' || b.custom_domain) partner.branding.dns_status = partner.branding.dns_status === 'verified' ? 'verified' : 'pending_verification';
        return delay(partner.branding as any) as unknown as T;
      }
      if (method === 'POST' && parts[2] === 'verify-domain') {
        partner.branding.dns_status = partner.branding.custom_domain ? 'verified' : 'not_configured';
        return delay(partner.branding as any) as unknown as T;
      }
      if (parts[2] === 'clients') {
        if (method === 'GET') return delay(partner.end_clients as any) as unknown as T;
        if (method === 'POST') {
          if (partner.license.client_seats_used >= partner.license.client_seats) throw httpErr(402, `License limit reached (${partner.license.client_seats} client seats on plan ${partner.license.plan})`);
          const c = {
            id: `ec-${partner.code.toLowerCase()}-${partner.end_clients.length + 1}`, partner_id: partner.id,
            name: b.name ?? 'Nouveau client', industry: b.industry ?? 'Non spécifié', city: b.city ?? 'Casablanca',
            devices: Number(b.devices ?? 0), users: Number(b.users ?? 0), plan: b.plan ?? 'SME',
            monthly_mrr_eur: Number(b.monthly_mrr_eur ?? 0), status: 'onboarding' as const, since: new Date().toISOString().slice(0, 10),
          };
          partner.end_clients.push(c);
          partner.license.client_seats_used += 1;
          partner.license.devices_used += c.devices;
          return delay(c as any) as unknown as T;
        }
        const cid = parts[3];
        const idx = partner.end_clients.findIndex(x => x.id === cid);
        if (idx < 0) throw httpErr(404, 'Demo: end-client not found');
        if (method === 'PATCH') {
          const before = partner.end_clients[idx].devices;
          Object.assign(partner.end_clients[idx], b);
          partner.license.devices_used += (Number(b.devices ?? before) - before);
          return delay(partner.end_clients[idx] as any) as unknown as T;
        }
        if (method === 'DELETE') {
          partner.license.client_seats_used = Math.max(0, partner.license.client_seats_used - 1);
          partner.license.devices_used -= partner.end_clients[idx].devices;
          partner.end_clients.splice(idx, 1);
          return delay(undefined as any) as unknown as T;
        }
      }
    }

    // ---- Organizations (platform admin) ----
    if (root === 'organizations') {
      if (method === 'GET' && parts.length === 1) {
        return delay(orgs.map(o => ({
          id: o.id, name: o.name, tier: o.tier, status: 'active',
          contact_email: `ops@${o.name.toLowerCase().replace(/[^a-z]/g, '')}.example`, contact_phone: null,
          industry: 'Technology', country: 'FR',
          member_count: demoTechnicians.filter(t => t.orgId === o.id).length,
          asset_count: demoDevices.filter(d => d.orgId === o.id).length,
          risk_score: 30 + o.id * 4, compliance_score: 92 - o.id * 3,
          monthly_revenue: [4500, 8900, 1200][o.id - 1] ?? 1200, created_at: iso(40000),
        })) as any) as unknown as T;
      }
      if (method === 'POST') {
        const o = { id: orgs.length + 1, name: b.name ?? 'New Demo Tenant', tier: b.tier ?? 'basic', ticketing: false };
        orgs.push(o);
        return delay({ id: o.id, name: o.name, tier: b.tier ?? 'basic', status: 'active', contact_email: b.contact_email ?? '', contact_phone: b.contact_phone ?? null, industry: b.industry ?? null, country: b.country ?? null, member_count: 0, asset_count: 0, risk_score: 0, compliance_score: 0, monthly_revenue: 0, created_at: iso(0) } as any) as unknown as T;
      }
      if (method === 'GET' && parts.length === 2) {
        const o = orgs.find(x => x.id === Number(parts[1]));
        if (!o) throw httpErr(404, 'Demo: organization not found');
        return delay({ id: o.id, name: o.name, tier: o.tier, status: 'active', contact_email: '', contact_phone: null, industry: null, country: null, member_count: demoTechnicians.filter(t => t.orgId === o.id).length, asset_count: demoDevices.filter(d => d.orgId === o.id).length, risk_score: 0, compliance_score: 0, monthly_revenue: 0, created_at: iso(0) } as any) as unknown as T;
      }
      if (method === 'PATCH') {
        const o = orgs.find(x => x.id === Number(parts[1]));
        return delay({ id: o?.id ?? Number(parts[1]), name: o?.name ?? 'Demo tenant', tier: b.tier ?? 'enterprise', status: b.status ?? 'active', contact_email: b.contact_email ?? '', contact_phone: null, industry: null, country: null, member_count: 0, asset_count: 0, risk_score: 0, compliance_score: 0, monthly_revenue: 0, created_at: iso(0) } as any) as unknown as T;
      }
    }

    throw httpErr(404, `Demo mode: no simulated handler for ${method} /api${path}`);
  },
};
