# Guide démarrage rapide client (placeholder — PROMPT D2)

Étapes types : 1) Connexion + MFA 2) Inviter l'équipe (Team & Roles) 3) Activer Demo Mode pour évaluer / ou pousser le dataset démo 4) Configurer Auto Discovery (SNMP credentials + OID) → Add to monitored 5) Créer un ticket avec pièce jointe 6) Suivre un projet (config SLA, documents) 7) Lire un rapport PDF/CSV 8) Notifications (cloche, ack, retry).
Comptes de test fournis au client : admin@damanecash.ma / soc@valorissystem.ma / it@vivalissalaf.ma (mot de passe remis hors doc).
