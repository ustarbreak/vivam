# MATRICE RBAC OFFICIELLE (D8)
> Source : `src/context/AuthContext.tsx`, `src/components/Layout.tsx` (nav par rôle), `backend/app/routers/*.py` (contrôles serveur). Vérifiée contre le code, pas spéculative.

## 1. Rôles existants
| Rôle | Obtenu comment | Portée données | Route home |
|---|---|---|---|
| `platform_admin` | Seed backend / login ops@infracentra.ma | TOUS les tenants (`callerOrgId()` renvoie null L37 demoMode.ts ; bypass serveur) | `/admin/dashboard` |
| `partner_admin` | Domaine email du partenaire ou mapping AuthContext L125-132 | Ses end-clients uniquement (filtrage `partner_id`) | `/partner/dashboard` |
| `client_admin` | Seed tenant / login admin@{tenant}.ma | Son tenant (`org_id` du JWT) | `/client-admin/dashboard` |
| `client_user` | Invitations via POST /users | Son tenant, lecture + actions limitées | `/dashboard` |

## 2. Matrice rôles × ressources × actions
Légende : ✅ autorisé · 🔒 autorisé sur SON tenant seulement · ⛔ interdit (403 serveur ou absent de la nav) · 🅓 démo-only (endpoint réel manquant — voir ROUTING-MATRIX §G) · 🔑 selon entitlements du plan

| Ressource / Action | platform_admin | partner_admin | client_admin | client_user | Contrôlé où ? |
|---|---|---|---|---|---|
| **Organizations** — lire tous | ✅ | ⛔ | ⛔ | ⛔ | organizations.py filtre org_id |
| **Organizations** — CRUD | ✅ | 🔒 (ses end-clients) 🅓 | ⛔ | ⛔ | organizations.py + filtrage partner |
| **POST /seed-demo-tenant** | ✅ | ⛔ | ⛔ | ⛔ | settings.py `_require_platform_admin` L21-23 (appel L112) |
| **PUT /settings/system** | ✅ | ⛔ | ⛔ | ⛔ | idem `_require_platform_admin` |
| **Tickets** — créer | ✅ | 🔒 | 🔒 | 🔑 | tickets.py filtre org_id |
| **Tickets** — éditer statut/assignee/notes | ✅ | 🔒 | 🔒 | ⛔ | PATCH /tickets/{uid} |
| **Tickets** — evidence/fichiers upload+download | ✅ | 🔒 | 🔒 | 🔑 | /{uid}/evidence POST, GET …/file |
| **Tickets** — approvals / closure-request | ✅ | 🔒 | 🔒 | ⛔ | /{uid}/approvals/{id}/decide |
| **Tickets** — workload global | ✅ | 🔒 (ses clients) | ⛔ | ⛔ | GET /ops/workload |
| **Alerts** — lire / ack | ✅ | 🔒 | 🔒 | 🔑 | GET/POST /alerts, /{id}/ack |
| **Notification rules** — CRUD | ✅ | 🔒 | 🔒 | ⛔ | notification-rules.py |
| **Notifications** — ack / retry dead letters | ✅ | 🔒 | 🔒 | ⛔ | /notifications/{id}/ack, /retry-dead-letters |
| **Playbooks** — CRUD + run | ✅ | 🔒 | 🔒 | ⛔ | router playbooks |
| **Scripts AI** — générer playbook | ✅ | 🔒 | 🔒 | ⛔ | POST /playbooks/generate |
| **Runbooks** — auto-gen depuis doc IT | ✅ | 🔒 | 🔒 | ⛔ | POST /projects?runbook |
| **Projects kind=internal** — CRUD | ✅ SEUL | ⛔ | ⛔ | ⛔ | projects.py L64/L134 : internal réservé platform_admin |
| **Projects kind=client** — CRUD | ✅ (assignation org) | 🔒 | 🔒 | 🔑 lecture | L154-155 : `role != platform_admin and p.org_id != user.org_id → 403 Cross-tenant access denied` |
| **Project attachments** — upload/delete | ✅ | 🔒 | 🔒 | 🔑 upload | /{pid}/attachments POST/DELETE |
| **Discovery scans** — lancer/lire | ✅ | 🔒 | 🔒 | ⛔ | discovery.py |
| **SNMP credentials** — CRUD | ✅ | 🔒 | 🔒 | ⛔ | /snmp-credentials |
| **Import device → monitored** | ✅ | 🔒 | 🔒 | ⛔ | POST /devices/{id}/import |
| **Entitlements** — lire | ✅ | 🔒 | 🔒 | 🔑 | entitlements.py |
| **Entitlements** — souscrire/résilier | ✅ | 🔒 wholesale | 🔒 plan propre | ⛔ | POST/DELETE /entitlements |
| **Users** — CRUD équipe | ✅ | 🔒 (sa team) | 🔒 (sa team) | ⛔ | users.py |
| **Reports** — catalogue/page/export | ✅ (+filtre tenant) | ✅ (+filtre ses tenants) | 🔒 (son tenant, pas de sélecteur UI) | ⛔ prévu | reports_router ; ReportsPage verrouille orgId hors platform/partner |
| **Value engine** — receipt/proof-pack | ✅ | 🔒 | 🔒 | 🔑 | value.py |
| **Partners program** — stats/sessions training | ✅ 🅓 | 🔒 🅓 | ⛔ | ⛔ | router partner à créer (écart G) |
| **Audit log global** | ✅ | ⛔ | 🔒 (/logs/my-org) | ⛔ | audit.py : deux endpoints distincts |
| **Demo Accounts tab (UI Settings)** | ✅ visible | ✅ visible | ⛔ masqué | ⛔ | SettingsPage.tsx L103 : `isPlatformAdmin \|\| isPartnerAdmin` |
| **Nav Integrations/Architecture (UI client)** | ✅ | ✅ | masquée volontairement | masquée | Layout.tsx servicesNav — réaffichage : ROUTING-MATRIX §G |

## 3. Mécanismes d'isolation vérifiés dans le code
1. **Front** : `AuthContext` attache `orgId` au user ; `api.ts` signe chaque requête avec le JWT ; en démo `callerOrgId()` renvoie l'org de session et `demoMode` filtre tous les stores par cette org (sauf platform_admin → `null` = tout voir, L37).
2. **Backend** : chaque router dépend de `get_current_user` (JWT) ; requêtes SQL `WHERE org_id = current_user.org_id` ; cross-tenant explicite en 403 (projects.py L154-155, pattern dupliqué ailleurs). Le tenant ne vient JAMAIS d'un paramètre URL — seul le JWT fait foi.
3. **MFA** : `POST /login` sans `response_model` déclaré on purpose pour gérer le challenge TOTP (auth.py).

## 4. Écarts détectés (UI vs API) — à corriger
| # | Écart | Risque | Correctif |
|---|---|---|---|
| E1 | `client_user` peut atteindre `/client-admin/*` par URL directe (`ProtectedRoute` App.tsx L108-113 ne teste que l'authentification) | Faible en démo (données déjà filtrées org) ; en réel certaines pages exposent des configs | Ajouter un wrapper `<RoleRoute roles={[…]}>` sur les routes client-admin et admin/* |
| E2 | Partner : aucune vérification serveur `partner_id` (router partner inexistant) | Bloquant avant facturation MSP | Créer partner.py s'appuyant sur `current_user.partner_id` |
| E3 | Password reset par email non implémenté côté réel | Moyen | Nouvel endpoint branché sur le job SMTP existant (notifications.py) |
| E4 | Reports : filtre tenant ouvert à partner_admin côté UI sans contrôle serveur d'appartenance tenant↔partner | Moyen | Dans reports_router, si role=partner_admin vérifier la liaison tenant↔partner |

## 5. Recette développeur — modifier un droit
- **Accorder une page à un rôle** : ajouter l'entrée dans le bon bloc de `Layout.tsx` (operationsNav/adminNav/servicesNav ~L183-300) PUIS autoriser côté serveur dans le router concerné.
- **Retirer une action** : supprimer le bouton/handler dans la page + le `@router.<method>` correspondant ; ne jamais se limiter au masquage UI.
- **Nouveau rôle** : étendre `User['role']` (types AuthContext), ajouter un bloc nav dans Layout.tsx, ajouter le case de gating dans les routers FastAPI. Tester le 403 avec un token d'un autre rôle (script multi-tenant Phase 8).
