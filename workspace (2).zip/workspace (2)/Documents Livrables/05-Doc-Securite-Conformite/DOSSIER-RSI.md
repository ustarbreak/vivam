# Dossier sécurité pour RSSI client (placeholder — PROMPT D7)

Points couverts : architecture zero-inbound (collector → HTTPS sortant uniquement, one-time enrollment key), chiffrement AES-256 repos / TLS 1.3 transit, isolation multi-tenant par JWT (org jamais issu de l'URL), bcrypt+TOTP, RBAC complet, audit immuable + hash des exports PDF, résidence des données (hybride/on-prem possible), mapping conformité ISO 27001 / SOC 2 / NIS2 / PCI-DSS / RGPD / loi marocaine 09-08 par module, SLA support et réponse à incident.
RBAC-MATRIX.md : matrice rôles×ressources×actions (prompt D8) à générer depuis AuthContext + routers backend.
