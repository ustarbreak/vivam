# Manuel maintenance & troubleshooting Owner (placeholder — PROMPT D4)

Index des pannes connues déjà rencontrées :
| Symptôme | Cause | Fix |
|---|---|---|
| start.bat se ferme instantanément / 'vite not recognized' | node_modules incomplet (dossier vite présent mais binaire absent) | utiliser start-verbose.bat (log demo-launch.log) ; rm -rf node_modules package-lock.json && npm install ; fallback `node node_modules/vite/bin/vite.js` |
| ECONNREFUSED proxy /api | backend down ou IPv6 localhost | cible 127.0.0.1:8000 (déjà corrigé) ; relancer start-fullstack.bat |
| Erreur SQLite résiduelle | ancien fichier .db orphelin | supprimer le db temporaire périmé puis `alembic upgrade head` |
| Chiffres incohérents entre pages en démo | constante en dur réintroduite | rebrancher sur demoWorld/computeDemoStats() |
| Notification jamais reçue en réel | SMTP/webhook non configurés | renseigner env, tester via Retry failed |
Procédures à compléter via D4 : backup/restore Postgres, rotation secrets, monitoring plateforme, healthchecks jobs H/J/M.
