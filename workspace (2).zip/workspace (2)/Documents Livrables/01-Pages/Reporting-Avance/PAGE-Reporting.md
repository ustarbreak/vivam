# FICHE — Advanced Reporting (20 rapports / 6 familles / 62 pages)

> Route : `#/reports/{reportId}/{page}` · Composant : `ReportsPage.tsx` · Catalogue : `src/data/reportPrototype.ts` + `reportsApi.ts` · Backend : routers reports + builders.

Structure cible (brief §2) : Direction & valeur (1,9,19) · Menaces & détection (2,11,17,14) · Incidents & réponse (3,18,8) · Vulnérabilités & posture (6,12,15) · Infrastructure & résilience (5,7,13,16) · Conformité & audit (4,20,10). Total = 5 + 19×3 = 62 pages. Navigation 3 niveaux (familles ▸ onglets rapports ▸ pastilles pages) ; téléchargements 4 niveaux (page/rapport/famille/tout) ; Download Center = page 5 du rapport 1.

Blocs contractuels : K,R,B,T,M,L + S,G,F,D,H,C,P. Codes couleur o,b,w,h,1,2,3. Badges '@crit:…'.

Accès & RBAC :
- client_admin : VOIT ses rapports, verrouillé sur son orgId (aucun sélecteur).
- platform_admin & partner_admin : dropdown filtre **Tenant** (recharge le rapport du client choisi). Partner limité à SES end-clients.
- Autres rôles : pas de reporting (sidebar masquée).

Exports : PDF (navigateur headless, thème clair forcé, sauts de page, logo+en-tête client, hash stocké) et CSV (server-side depuis les mêmes données que l'écran, UTF-8 BOM). Journal export : client/user/rapport/période/date.
Données indispo : bloc "Donnée indisponible" + date de dernière MAJ — jamais de zéro trompeur. Démo : reportPrototype.ts derrière indicateur mode démo explicite.
Pannes : chiffres écran ≠ PDF → l'export doit relire l'API, pas le DOM ; rapport vide → message "Aucun incident sur la période".
