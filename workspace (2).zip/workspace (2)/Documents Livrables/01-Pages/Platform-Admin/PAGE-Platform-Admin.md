# FICHE — Portail Platform Admin (owner)

> Rôles : platform_admin uniquement. Home après login : `#/admin/dashboard`. Comptes démo : ops@infracentra.io (+ admin/analyst@infracentra.io).
> ⚠️ Le Tenant Manager et la gestion des clients/partenaires vivent ICI, jamais côté client admin.

| Page | Route | Composant (`src/pages/platform/`) | Points clés |
|---|---|---|---|
| Platform Dashboard | `#/admin/dashboard` | PlatformDashboardPage.tsx | KPI globaux tous tenants, santé intégrations, MRR |
| Tenant Manager | `#/admin/clients` | PlatformClientsPage.tsx | CRUD organisations, plans Pro/Mid/Enterprise/SME, member_count/asset_count RÉELS (dérivés demoWorld en démo), seed tenant |
| Partners (MSP) | `#/admin/partners` | PlatformPartnersPage.tsx | Vue globale multi-partenaires (Atlas Cyber Services, Oasis IT Partners…), validation onboardings, scores Value&Loyalty canal |
| Services Overview | `#/admin/services` | PlatformServicesOverviewPage.tsx | état des 16 services par tenant, gating entitlements |
| Integrations | `#/admin/integrations` | PlatformIntegrationsPage.tsx | config connecteurs réels (endpoints/tokens via env, JAMAIS en dur) |
| Audit | `#/admin/audit` | PlatformAuditPage.tsx | audit trail global + journal des exports (hash PDF) |
| Demo Accounts | dans Settings plateforme | SettingsPage.tsx (onglet visible ici seulement) | génération des comptes marocains de démo ; MASQUÉ pour client_admin |
| Reporting filtré | `#/reports` | ReportsPage.tsx | dropdown **Tenant** actif (voir fiche Reporting-Avance) |

RBAC serveur : chaque endpoint `/api/admin/*` exige le claim role=platform_admin ; un client_admin appelant → 403 (test automatisé d'isolation).
