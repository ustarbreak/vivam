# FICHE — Landing page publique

> Dossier : `src/pages/landing/` · Routes ancrées : #about #services #products #pricing #clients #partners #mssp #industries #compare.

- ClientsSection : Damanecash, Valoris System, Vivalis Salaf, Galenica, Amigraph, HydroPlus (témoignages synchronisés avec ces clients).
- PartnersSection : Fortinet, Microsoft, CrowdStrike, Palo Alto Networks, Splunk, Tenable, Veeam, Cisco (aucun outil interne visible).
- PricingSection : pay-per-seat — SME 19$/siège (min 5), Mid-Market 29$/siège (min 15), Enterprise custom (volume dès 50), −20% annuel.
- Header Produits : colonnes "Unified Security Platform" + "AI Triage & Prediction" uniquement (produits réels).
- Why Infracentra : About Us, Industry Recognition (#partners), Customer Stories (#clients), Find a Partner (#mssp), Industries (fintech/santé/industrie/tech/public), Compare (Splunk/Sentinel/CrowdStrike/QRadar).
- Modifier : textes centralisés dans `navigationData.ts` + composants section ; aucun bouton href="#" ne doit subsister (contrôle ROUTING-MATRIX).
