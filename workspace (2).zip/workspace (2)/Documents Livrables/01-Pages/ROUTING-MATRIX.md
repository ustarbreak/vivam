# ROUTING MATRIX — routes, redirects, pages masquées

## Redirects de compatibilité (ancien → nouveau)
| Ancienne route | Nouvelle | Statut |
|---|---|---|
| `#/operations` | `#/dashboard` | redirect 301-equivalent (App.tsx) |
| `#/tickets` | `#/service-desk` | idem |
| `#/notification-engine` | `#/notifications` | idem |
| `#/custom-playbooks` | `#/automation/playbooks` | idem |
| `#/soar` | `#/automation/playbooks` | idem |
| `#/devices` / `#/monitored-devices` | `#/asset-inventory/devices` | idem |
| `#/auto-discovery` | `#/asset-inventory/discovery` | idem |
| `#/reports` (sans id) | `#/reports/1/1` | idem |

## Pages MASQUÉES temporairement (route conservée, entrée sidebar retirée)
- **Architecture & Intégration** (`#/architecture`) : cachée sur demande client.
  ➜ Pour la remettre en ligne : dans `src/components/Layout.tsx`, retirer le flag `hidden: true` de l'entrée concernée (constante NAV_SECTIONS), puis rebuild. La route reste fonctionnelle entre-temps (accès direct par URL).
- ITDR, Multi-Layer AI™, autres produits non développés : aucune route créée (supprimés du menu ET de la landing).

## Règle anti-boutons-morts
Tout bouton/lien doit avoir : une route hash existante, OU un handler d'action API, OU être supprimé. Contrôle par grep récurrent :
`grep -rn 'href="#"' src/ && grep -rn 'onClick={() => {}}' src/` → doit retourner vide avant chaque release.

## Command Palette (Ctrl+K / Cmd+K)
Recherche floue sur TOUS les libellés + alias historiques ("tickets"→Service Desk, "SOAR"→Playbooks…). Index défini dans `components/CommandPalette.tsx`.
