# FICHE PAGE — Asset Inventory (Auto Discovery / Scan History / Monitored Devices) (D5)
**Parent nav** : dropdown « Asset Inventory » (Layout.tsx L265-269 client_admin, L214-218 partner) · **Composants** : `src/pages/client-admin/MonitoredDevicesPage.tsx` (exports multiples !)

## 1. Les 3 sous-pages
| Sous-item nav | Route hash | Export du composant | Rôle |
|---|---|---|---|
| Auto Discovery | `/#/client-admin/monitored-devices` | `MonitoredDevicesPage` (default) | Lancer des scans, gérer credentials SNMP v2c/v3 + OID list |
| Scan History | `/#/client-admin/scan-history` | `ScanHistoryPage` (named) | Historique runs + devices découverts par scan |
| Monitored Devices | `/#/client-admin/asset-inventory` | `MonitoredAssetsPage` (named) | Inventaire supervisé : tenant de rattachement + projet lié + preview SNMP complet |

⚠️ Piège connu pour les devs : les 3 pages vivent dans UN SEUL fichier `MonitoredDevicesPage.tsx`. Toujours vérifier quel export est importé dans App.tsx L60 (`import MonitoredDevicesPage, { ScanHistoryPage, MonitoredAssetsPage } from …`).

## 2. Endpoints
| Action UI | Réel `/api` | Démo (`demoMode.ts`) |
|---|---|---|
| Credentials SNMP CRUD | GET/POST/DELETE `/snmp-credentials` | root `snmp-credentials` L460-463 |
| Lancer un scan (CIDR, paramètres) | POST `/scans` (202 async) | L467 : crée scan + génère discoveredDevices |
| Liste scans | GET `/scans` ; détail GET `/scans/{id}` | L466/L476 |
| Devices d'un scan | GET `/scans/{id}/devices` | L475 filtre `scan_id` |
| Tous devices découverts | GET `/devices` | root `devices` L479 |
| **Add to monitored** (bouton par device) | POST `/devices/{id}/import` | L480 : passe `imported=true` → apparaît dans Monitored Assets |
| Disponibilité moteur nmap | GET `/engine-status` | L482 : `{nmap_available:false, mode:'demo-simulated'}` |

## 3. Logique de matching SNMP (règle métier clé)
À l'affichage des résultats de scan, chaque device est confronté aux credentials+OID enregistrés : match → badge vert « SNMP ✓ matched » + bouton **Add to monitored** actif ; pas de match → bouton grisé « No SNMP match ». Après import : récupération sysDescr/sysUpTime/ifTable (+CPU/RAM si MIB supportée) et supervision active. Le device importé rejoint demoWorld → cohérent avec Dashboard/Network/DeviceStatistics (mêmes hostnames/IPs).

## 4. Où modifier quoi
| Besoin | Emplacement |
|---|---|
| Colonnes du tableau Monitored (ajouter "VLAN", "Site"…) | rendu table `MonitoredAssetsPage` dans MonitoredDevicesPage.tsx ; enrichir le type DiscoveredDevice (devant le fichier) + réponse backend discovery.py |
| Champs du formulaire Scan Parameters | state form page default-export + POST body + modèle ScanRequest backend |
| Version SNMP supportée / ports | constante de paramètres scan en tête de fichier + connecteur discovery backend (nmap args) |
| Règle de matching (ex. accept v2c community string) | fonction de comparaison dans le rendu results + côté réel `backend/app/services` discovery |
| Affichage Tenant/Projet sur chaque device | colonne existante dans MonitoredAssetsPage : valeurs issues de `demoTenantName()`/projectsStore — en réel joindre org_id + project_id |

## 5. Tests de non-régression
1. Créer credential SNMP v3 (auth SHA/AES) → listé.
2. Lancer scan CIDR 10.0.0.0/24 → historique affiche le run → devices avec badges match.
3. Cliquer Add to monitored sur un device matché → il apparaît immédiatement dans Monitored Devices avec tenant+projet et preview SNMP.
4. Vérifier cohérence croisée : DeviceStatistics & Network affichent le même hostname/IP.
5. Réafficher le dropdown sans re-render complet : navigation interne au groupe OK (composant group Layout L265).
