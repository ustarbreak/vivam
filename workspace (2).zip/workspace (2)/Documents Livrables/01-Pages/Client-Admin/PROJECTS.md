# FICHE PAGE — Projects / Project Portfolio (D5)
**Route** : `/#/projects` (identique pour tous rôles, page auto-adaptative) · **Composant** : `src/pages/projects/ProjectsPage.tsx` · **Service API** : `src/services/projectsApi.ts`

## 1. Logique de cloisonnement (la plus importante à comprendre)
| Rôle connecté | Ce qu'il voit | Règle serveur (`backend/app/routers/projects.py`) |
|---|---|---|
| platform_admin | Projets **internes** = chantiers Infracentra↔clients ; peut créer côté client via sélecteur org | L64 : liste filtrée ; L134 : `kind="internal" if role=="platform_admin" else "client"` ; cross-tenant lecture ✅ |
| partner_admin | Projets de SES end-clients seulement | filtre partner_id (⚠️ réel à créer, démo OK) |
| client_admin | 2 sections : "Projets avec Infracentra" (kind=client, pilotés par vous) + "Projets internes au client" | L154-155 : `org_id != user.org_id → 403 Cross-tenant access denied` |
| client_user | Lecture seule selon entitlements | idem |

## 2. Endpoints
| Action UI | Réel `/api` | Démo (`demoMode.ts` root `projects`, L485+) |
|---|---|---|
| Liste | GET `/projects` | store filtré kind+org (L487-493) |
| Créer (modale) | POST `/projects` | push + audit (L495) |
| Fiche détail (bouton Show 👁) | GET `/projects/{pid}` | lookup |
| Éditer (bouton Edit ✏️) | PATCH/PUT `/projects/{pid}` | merge body |
| Supprimer (bouton Delete 🗑) | DELETE `/projects/{pid}` | splice store |
| Configuration ⚙️ (SLA h, alerte retard j, seuil risque, budget, auto-close tickets, notifications) | PUT `/projects/{pid}/config` | merge config JSON (⚠️ vérifier champ config models côté réel) |
| Jalons : cocher/ajouter | POST `/projects/{pid}/milestones`, PATCH `/projects/milestones/{id}` | L… stores |
| Timer chrono start/pause | POST `/projects/{pid}/timer/{action}` | timestamp cumul |
| Pièces jointes projet (image/PDF/config/txt) | POST `/projects/{pid}/attachments` · GET `…/attachments` · GET `…/attachments/{att_id}/file` · DELETE `…/attachments/{att_id}` | base64 in-memory |
| Runbooks auto-gen depuis doc IT | POST `/projects?runbook=true` ou `/projects/runbooks-from-doc {name, description, doc}` | L498-508 : chaque ligne du doc → un step, crée projet marqué `generated_from_doc`, ticket_category `runbook-…` |

## 3. Où modifier quoi
| Besoin | Emplacement |
|---|---|
| Libellés boutons Show/Edit/Delete/Config | JSX carte+ligne dans ProjectsPage.tsx (grep "Edit"/"Delete") |
| Champs de la modale création (+ upload fichier description) | state form en tête de composant ; le bouton d'attachement appelle déjà POST attachments après création — motif réutilisable |
| Ajouter une tuile KPI sur la carte projet | rendu carte : ajouter `{p.<champ>}` ; miroir dans type TS `Project` (projectsApi.ts) ET TicketResponse backend si persistant |
| Statuts projet / couleurs badges | table statut→classe CSS en tête de fichier |
| Comportement timer | handler `timer(action)` + persistance `time_spent_min` |
| Étendre l'auto-génération runbooks (format doc, max steps) | bloc L498-508 demoMode + endpoint réel à porter dans projects.py |

## 4. Dépendances & cohérence démo
`AuthContext` (rôle), `demoWorld.ts` (tenants Damanecash/Valoris/Vivalis, techniciens assignés), événements `demo-world-pushed`. Les projets listent les tickets liés par `ticket_category` ↔ Service Desk.

## 5. Tests de non-régression
1. Login platform admin → créer projet → il apparaît EN TANT QU'interne, invisible côté client.
2. Login admin@damanecash.ma → voir uniquement ses projets ; tenter URL directe d'un projet Valoris → masqué/403.
3. Upload image+PDF dans un projet → download → delete → liste à jour.
4. Timer start 1 min → pause → temps cumulé incrémenté.
5. Runbooks : coller doc 5 lignes → auto-generate → 5 steps ordonnés créés.
