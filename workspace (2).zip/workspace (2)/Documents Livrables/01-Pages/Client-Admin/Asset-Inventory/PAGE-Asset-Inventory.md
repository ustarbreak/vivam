# FICHE — Asset Inventory (dropdown : Auto Discovery / Scan History / Monitored Devices)

> Routes : `#/asset-inventory/discovery` · `#/asset-inventory/scans` · `#/asset-inventory/devices`
> Composants : `AutoDiscoveryPage.tsx` (scan params + credentials SNMP/OID), `MonitoredDevicesPage.tsx`, `ServiceDeviceManager.tsx`, `DeviceDetails.tsx`

## Flux principal (règle produit)
1. Configurer **Scan Parameters** : plages IP/subnets + credentials **SNMP v3/community** + **OID** requis.
2. Lancer scan (`POST /api/discovery/scan`) → résultat dans **Scan History**.
3. Chaque device scanné : matching automatique contre credentials+OID.
   - Match → badge vert "SNMP ✓ matched" + bouton **Add to monitored** → ajouté instantanément aux Monitored Devices avec toutes les infos SNMP remontées (sysDescr, uptime, ifTable, CPU/RAM si supporté).
   - No match → bouton grisé "No SNMP match".
4. **Monitored Devices** : chaque ligne affiche **le client/tenant** (Damanecash/Valoris/Vivalis) et **le projet lié**, plus preview complet.

| Élément | Réel | Démo |
|---|---|---|
| Inventaire supervisé | table `assets` filtrée tenant | 24 devices demoWorld (mêmes hostnames partout) |
| Compteurs membres/assets d'un tenant | SQL count | calculés via member_count/asset_count démo |
| Dropdown navigation Asset Inventory | — | entrées isolées supprimées de la sidebar |

Pannes : device ajouté absent du Dashboard → le compteur du dashboard lit computeDemoStats(), s'assurer que l'ajout démo mutate le même tableau demoWorld.devices.
