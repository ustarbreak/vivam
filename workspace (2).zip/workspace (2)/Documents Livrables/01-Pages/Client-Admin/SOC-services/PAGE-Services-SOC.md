# FICHE — Pages services SOC (Section B)

Threat Intel Feed (`ThreatsPage.tsx`, connecteurs renseignement menaces), IR Workspace (`IncidentsPage.tsx` + gestion de cas), Vulnerability Management (`VulnerabilityScanningPage.tsx`), Patch & Remediation (`PatchManagementPage.tsx` + `PSAPage.tsx`), Endpoint Security (`EndpointProtectionPage.tsx`), Email Defense (`EmailSecurityPage.tsx`), Cloud Workload Protection (`CloudSecurityPage.tsx`), Service Analytics (`AnalyticsPage.tsx`), Service Catalog (`My Services`/`ServiceDetailPage.tsx`).

- Point d'entrée unique données : `src/services/serviceData.ts` + hooks live. Brancher une page sur le réel = 2 lignes (documenté dans INTEGRATIONS-OSS.md).
- Confidentialité : les libellés UI utilisent des catégories ("renseignement sur les menaces", "supervision"), jamais MISP/Wazuh/etc. Les noms réels restent dans `backend/app/services/connectors.py`.
- Gating plan : un service non inclus au plan du tenant (ClientEntitlementsPage) est masqué en sidebar ET refuse l'API (403).
