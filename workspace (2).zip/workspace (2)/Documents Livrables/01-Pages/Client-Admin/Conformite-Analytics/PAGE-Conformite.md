# FICHE — Compliance Posture & Analytics

Compliance Reports (`ComplianceReports.tsx` + `CompliancePage.tsx`) : référentiels NIST/SOC2/ISO27001/RGPD/HIPAA/PCI/NIS2, contrôles auto + validation humaine ("validé par", date). Backend : router compliance + table controls ; source réelle = scans de configuration (catégorie "supervision").
Analytics (`AnalyticsPage.tsx`) : agrégats kpi_daily/kpi_monthly via API reporting.
Démo : scores déterministes demoWorld ; cohérents avec rapport #4/#20 du Reporting avancé.
