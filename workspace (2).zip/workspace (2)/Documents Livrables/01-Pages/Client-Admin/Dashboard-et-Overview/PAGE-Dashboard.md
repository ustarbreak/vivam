# FICHE — Executive Dashboard (Client Admin)

> Route : `#/dashboard` · Rôles : client_admin, technician, analyst (selon entitlements)
> Composant : `src/pages/DashboardPage.tsx` (+ `src/pages/client-admin/ClientAdminDashboard*.tsx`)
> Fusionné avec : Value & Loyalty (`CustomerValueDashboard.tsx`) et Overview historique.

## 1. Identité & accès
| Élément | Valeur |
|---|---|
| Route active | `#/dashboard` (alias "Operations" → redirect 301 vers dashboard, voir NAVIGATION-MIGRATION.md) |
| Sidebar | Section A "Dashboard & Intelligence" → **Executive Dashboard** |
| RBAC | client_admin oui ; platform_admin non (voit PlatformDashboardPage) |
| Données démo tenant | Damanecash (Pro), Valoris System (Enterprise), Vivalis Salaf (SME) selon login |

## 2. Fonctionnalités principales
| # | Élément UI | Effet | Endpoint réel | Intercepteur démo |
|---|---|---|---|---|
| 1 | Cartes KPI (menaces actives, auto-remediated, devices online, tickets ouverts) | lecture seule, calculées | `GET /api/stats`, `/api/alerts` | `computeDemoStats()` de `demoWorld.ts` — TOUJOURS cohérent avec Alerts/Tickets/Devices |
| 2 | Sparklines comparatives (6 mois) | tendance | agrégats kpi_daily | séries déterministes demoWorld |
| 3 | Quick Actions panel (Create Ticket, Run Scan, Generate Report, Acknowledge Alert) | navigation/action | routes respectives | idem |
| 4 | Widgets ROI (Value Receipt, Ligne Rouge, Risk Score) | monétisation visible | `GET /api/v1/value/*` (value_engine.py) | données miroir démo synchronisées |
| 5 | Badge temps réel alertes P1 | écoute `notifications-changed` | — | moteur notifications démo |

## 3. Données
- Réel : PostgreSQL tables `alerts`, `assets`, `tickets`, `playbook_runs`, `kpi_daily`.
- Démo : `src/data/demoWorld.ts` (24 devices, 12 alertes ALR-0001.., 12 tickets TCK-01001.., 4 playbooks). Les chiffres codés en dur ("7", "23") ONT ÉTÉ SUPPRIMÉS — ne jamais réintroduire de constante locale.
- Événement `demo-world-pushed` → re-render complet via listener dans le composant.

## 4. Comment modifier
- Texte d'une carte : chercher le libellé dans `DashboardPage.tsx` (tableau `kpiDefs`).
- Ajouter une carte : dupliquer l'objet `<div className="card kpi">` + ajouter la métrique dans `computeDemoStats()` ET dans `/api/stats` backend pour rester synchro démo/réel.
- Supprimer un widget : retirer le JSX + son import hook si dédié.

## 5. Pannes typiques
| Symptôme | Cause | Fix |
|---|---|---|
| Chiffres différents d'AlertsPage | quelqu'un a remis une constante en dur | tout rebrancher sur `computeDemoStats()` |
| Dashboard vide en mode réel | API down | vérifier `127.0.0.1:8000` (start-fullstack.bat) |
| Ne se rafraîchit pas après Push Dataset | listener absent | écouter `demo-world-pushed` |

## 6. Checklist
Voir PAGE-FICHE-MODELE.md §6. Test spécifique : comparer "Menaces actives" du dashboard avec le compte des alertes critiques d'AlertsPage → identiques obligatoirement.
