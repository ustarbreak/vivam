# FICHE — Projects (côté client)

> Route : `#/projects` · Composant : `src/pages/projects/ProjectsPage.tsx` · Backend : routers projects + attachments.

Deux logiques distinctes :
- Projets AVEC Infracentra (livrables, jalons, SLA, timers, tickets liés) — créés aussi par la plateforme.
- Projets INTERNES du client (avec ses propres clients/sous-traitants) — visibles uniquement chez lui.

Boutons par projet : Show (détail), Edit, Delete (confirmation), ⚙ Configuration (SLA h, alerte retard j, seuil risque, budget, auto-close tickets, notifications → `PUT /projects/{id}/config`), 📎 Upload document (image/pdf/conf/txt) création + section pièces jointes (list/download/delete).
Timer : chrono temps passé cumulable par jalon. Lien ticketing : les tickets marqués project_id apparaissent dans l'onglet avancement.
Démo : demoProjects (internal vs client) — Damanecash migration Fortinet, Valoris ISO 27001, etc.
