# FICHE — Service Desk / Advanced Ticketing

> Route : `#/service-desk` · Rôles : client_admin, technician (assignés), analyst
> Composant : `src/pages/client-admin/AdvancedTicketingPage.tsx`
> Backend réel : `backend/app/routers/tickets.py` + modèles Ticket/TicketEvidence

## 1. Identité & accès
| Élément | Valeur |
|---|---|
| Sidebar | Section E "Operations & Ticketing" → **Service Desk** |
| RBAC | Vivalis Salaf (SME) : ticketing NON inclus au plan → page masquée |
| Compat | ancienne route `#/tickets` → redirect |

## 2. Boutons & handlers
| # | Élément UI | Handler | Endpoint réel | Démo (`demoMode.ts`) |
|---|---|---|---|---|
| 1 | New Ticket (modale création) | `createTicket()` | `POST /api/tickets` | crée TCK-xxxxx lié à une alerte ALR-xxxx de demoWorld |
| 2 | 📎 Joindre un fichier (création) | `attachOnCreate(file)` | multipart `POST /api/tickets/{id}/attachments` (base64 fallback) | stocke dans tableau attachments démo |
| 3 | Bouton config ⚙ à droite de chaque ticket non résolu | `openEditPanel()` | `PATCH /api/tickets/{id}` | mutation locale + event |
| 4 | Ajouter du texte / note de travail | `addWorkNote()` | `POST /api/tickets/{id}/notes` | timeline démo |
| 5 | Attacher fichier dans le détail | `uploadAttachment()` | idem #2 (images, PDF, txt, conf) | preview + download |
| 6 | Changer assignee / statut / priorité | `updateField()` | `PATCH /api/tickets/{id}` | techniciens = demoTechnicians uniquement |
| 7 | Export CSV liste | `exportCsv()` | `GET /api/tickets/export?format=csv` | génération côté client depuis dataset |
| 8 | Suivi SLA / escalade | auto | moteur SLA backend (responsible, due_at) | timers démo déterministes |

## 3. Données
- Réel : tables `tickets`, `ticket_notes`, `ticket_evidences` (fichiers), tenant_id via JWT.
- Démo : 12 tickets TCK-01001..01012 (demoWorld), liés aux 12 alertes et assignés Y. El Amrani/S. Bennani/N. Benali (Damanecash), K. Chraibi/A. Fassi (Valoris). Audit trail et evidence chain actifs.

## 4. Comment modifier
- Types de fichiers acceptés : constante `ALLOWED_EXT` en tête de la modale création.
- Workflow statuts : dictionnaire `STATUS_FLOW` (page) synchronisé avec enum backend `TicketStatus`.
- Ajouter une action au panneau config : dupliquer un bloc `<ActionRow>` + handler + case démo dans `demoMode.handle('PATCH','/tickets/...')`.

## 5. Pannes typiques
| Symptôme | Cause | Fix |
|---|---|---|
| Bouton attachement invisible | build démo périmé | `npm run build` / redémarrer dev server |
| Upload échoue en réel | taille > limite multipart | augmenter `MAX_UPLOAD_MB` env backend |
| Ticket orphelin d'un technicien | nom hors demoTechnicians | ne référencer QUE les techniciens démo |

## 6. Checklist
+ Test spécifique : créer un ticket avec image → recharger → pièce jointe toujours listable ET téléchargeable ; vérifier le même ticket dans Projects (lien projet→ticket).
