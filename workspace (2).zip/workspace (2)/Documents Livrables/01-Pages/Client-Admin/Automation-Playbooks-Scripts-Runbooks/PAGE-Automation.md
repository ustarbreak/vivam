# FICHE — Automation (dropdown : Playbooks / Scripts AI / Runbooks)

> Parent sidebar : **Automation** ▾ → 3 sous-pages.
> Routes : `#/automation/playbooks` · `#/automation/scripts` · `#/automation/runbooks`
> Composants : `SOARPage.tsx` (playbooks), `AutomationScriptsPage.tsx`, `AutomationRunbooksPage.tsx` (+ `CustomPlaybooksLibrary.tsx`)

| Sous-page | Boutons clés | Endpoint réel | Démo |
|---|---|---|---|
| Playbooks | Run now, Edit, Duplicate, Toggle active, Export | `/api/playbooks` (+runs) | 4 playbooks demoWorld ; runs incrémentent "auto-remediated" du Dashboard |
| Scripts AI | Générer un script/playbook depuis une intention NL, pousser dans le système | `POST /api/playbooks/generate` | génération simulée déterministe ; sortie = playbook injecté dans la liste |
| Runbooks | **New Runbook**, Auto-generate from doc IT, Create blank, Join session lab | `POST /projects/runbooks-from-doc` | crée un projet-runbook persistant marqué `generated_from_doc` ; steps = lignes de la doc (max 10) |

Rappel naming : "Custom Playbooks" (ancien) → les Runbooks projets vivent ici, pas dans le SOC.
Pannes : runbook sans steps → doc collée vide/une seule ligne ; vérifier le parsing puces/numéros dans le générateur.
