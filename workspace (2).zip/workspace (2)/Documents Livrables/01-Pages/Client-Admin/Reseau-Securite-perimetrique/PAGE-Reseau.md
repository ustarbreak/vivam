# FICHE — Réseau & Sécurité périmétrique (Section C)

Pages : Topology Visualizer (`InfrastructureMap`), Network Observability (`NetworkPage.tsx`), Perimeter Defense (`FirewallManagementPage.tsx`), SD-WAN Controller (`SDWANPage.tsx`), Secure Remote Access (`VPNGatewayPage.tsx`), DNS Security (`DNSFilteringPage.tsx`), Resilience & Recovery (`BackupDRPage.tsx`). Architecture & Intégration : MASQUÉE temporairement (voir ROUTING-MATRIX §hidden).

- Toutes consomment le hook `useServiceLiveFeed(serviceId)` : badge **LIVE FEED** en mode réel (connecteurs Netdata/LibreNMS/OPNsense/Tailscale/Pi-hole/Restic), mock synchronisé demoWorld en démo.
- Boutons d'action par service (ex. SD-WAN "Add connection", Firewall "Push rule") : appel `POST /api/services/{id}/action` relayé vers l'intégration configurée (table `integrations`). Sans intégration active → bouton visible mais réponse "integration not configured" (jamais silencieux).
- NetworkPage n'utilise plus sa liste propre : `mockNetworkDevices` dérivé des 24 devices demoWorld.
