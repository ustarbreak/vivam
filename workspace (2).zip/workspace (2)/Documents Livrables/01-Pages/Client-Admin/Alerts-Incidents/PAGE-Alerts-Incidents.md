# FICHE — Alerts / Incidents / Security History / Statistiques

> Routes : `#/alerts`, `#/incidents`, `#/security-history`, `#/statistics` (+ Network/Device/Performance stats)
> Composants : `AlertsPage.tsx`, `IncidentsPage.tsx`, `SecurityHistoryTimeline.tsx`, `StatisticsPage.tsx`, `DeviceStatistics.tsx`, `NetworkStatistics.tsx`, `PerformanceStatistics.tsx`
> Regroupés sous le dropdown sidebar **"Incidents & Statistics"** (au survol/clic).

## 1. Identité
Sidebar section A/B : Active Incidents (=alerts) ; Security History déplacé sous Incidents & Statistics ; Performance/Devices/Network stats idem.

## 2. Boutons & endpoints
| Élément | Endpoint réel | Démo |
|---|---|---|
| Liste alertes + ack | `GET/POST /api/alerts[/{id}/ack]` | mockAlerts 12 items ALR-0001.. (mêmes uid que moteur ticketing) |
| Créer ticket depuis alerte | `POST /api/tickets` (prefill alertUid) | TCK-xxxx cite l'ALR-xxxx d'origine |
| Timeline incident | `GET /api/incidents/{id}/events` | mockIncidents dérivés des tickets P1 (timelines citent TCK + assets réels) |
| Graphiques stats | agrégats kpi_daily | séries déterministes hostname-based |
| Export CSV | `/api/alerts/export` | client-side |

## 3. Règle de cohérence
Le compte des alertes critiques d'AlertsPage == "Menaces actives" du Dashboard == incidents P1 d'IncidentsPage. Toute divergence = donnée en dur réintroduite → supprimer, brancher sur demoWorld/mockData dérivé.

## 4. Modifier / Pannes
- Libellés gravité : `SEVERITY_LABELS` dans AlertsPage.
- DeviceStatistics n'a PLUS de devices codés en dur : généré depuis les 24 devices demoWorld (hostnames fw-edge-01, nas-backup-01…). Si on voit "server-web-01" → retour d'un ancien mock, à purger.
