# FICHE PAGE — Service Desk / Advanced Ticketing (D5)
**Route** : `/#/client-admin/advanced-tickets` · **Composant** : `src/pages/client-admin/AdvancedTicketingPage.tsx` · **Rôles** : platform_admin, partner_admin, client_admin (+ client_user 🔑 selon plan)

## 1. Endpoints utilisés
| Action UI | Méthode + chemin réel (`/api`) | Intercepteur démo (`demoMode.ts` root `tickets`, L282-360) |
|---|---|---|
| Liste tickets | GET `/tickets` | filtre store par org, calcule sla_status (L48) |
| Créer ticket | POST `/tickets` | push store + audit ; ⚠️ bouton joindre fichiers à la création |
| Fiche détail | GET `/tickets/{uid}` | lookup uid TCK-01001..01012 |
| Note / édition statut, assignee, priorité | PATCH `/tickets/{uid}` | L354 merge body |
| Pièces jointes (image/PDF/config/txt) | POST `/tickets/{uid}/evidence` (multipart/base64) · GET `…/evidence` · GET `…/evidence/{ev_id}/file` (download) | L314-335, stock base64 in-memory |
| Historique d'audit du ticket | GET `/tickets/{uid}/audit` | L336 (reverse chronologique) |
| Demande de clôture + double validation | POST `/tickets/{uid}/closure-request` · GET `…/approvals` · POST `…/approvals/{aid}/decide` | L338-352 |
| Workload techniciens | GET `/tickets/ops/workload` | L301 |
| Escalades SLA manuelles | POST `/tickets/ops/run-escalations` | L306-307 (breached → level+1 + audit) |
| Métadonnées tenants (création) | GET `/tickets/meta/tenants` | L300 |

## 2. Où modifier quoi
| Besoin | Emplacement |
|---|---|
| Texte des boutons ("Attach file", "Add note") | grep du libellé dans le JSX de `AdvancedTicketingPage.tsx` (rendu modales/liste) |
| Ajouter un champ au formulaire création | interface TS du state create-form en haut du fichier + payload POST + miroir dans `demoMode.ts` bloc `root==='tickets'` POST (L292) + modèle SQLAlchemy `backend/app/models` tickets |
| Nouvelle action sur un ticket (bouton) | handler existant pattern `const act = async (uid, patch) => { await api.patch(\`/tickets/${uid}\`, …) }` puis bouton `<button onClick={()=>act(t.uid,{…})}>` ; côté serveur ajouter le champ dans TicketResponse si persisté |
| Changer les statuts/transitions | table de statuts en tête du composant + enum backend models/tickets.py |
| Types de fichiers acceptés uploads | input `accept=` côté page + validation extension côté `tickets.py` endpoint evidence |
| Moteur SLA (délais, paliers escalade) | logique `slaStatus` L44-48 demoMode + worker backend notifications/sla |

## 3. Dépendances
`AuthContext` (rôle/orgId), `services/api.ts` (fetch central + interception démo), `services/ticketAttachments` (encodage fichiers), événements globaux écoutés : `demo-world-pushed`, `notifications-changed`.

## 4. Tests de non-régression (manuel)
1. Créer un ticket avec 1 image + 1 PDF → vérifier apparition liste evidence + download OK.
2. Ouvrir un ticket non résolu → ajouter une note → recharger → note persistée (démo : localStorage session).
3. Marquer P1 → déclencher règle notification → cloche badge +1.
4. Closure-request → decide approve → statut closed + entrée audit.
5. Mode réel : mêmes actions via Postman avec JWT client_admin d'un autre tenant → attendre 403 cross-tenant.
