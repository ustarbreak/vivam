# FICHE — Notifications (ex Notification Engine)

> Route : `#/notifications` · Composant : `NotificationEnginePage.tsx` + `components/NotificationBell.tsx`
> Backend : routers notifications/notification_rules ; moteurs SMTP/Webhook/SMS (`backend/app/services/`).

## Boutons & endpoints
| Élément | Réel | Démo |
|---|---|---|
| Règle email/SMS/webhook CRUD | `/api/notification-rules` | règles seed Damanecash/Valoris |
| Toggle canal actif | PATCH rule | flag local persistant |
| Cloche topbar : détail notif | `GET /api/notifications` | liste démo enrichie (corps, erreur webhook) |
| Acknowledge | `POST /notifications/{id}/ack` | idem + event notifications-changed |
| Retry failed (dead letters) | `POST /notifications/retry-failed` | rejeu file dead-letter démo |
| View all | navigation `#/notifications` | — |

## Configuration réelle (activer les canaux)
Env backend : SMTP_HOST/USER/PASS (ou Mailcow/Rspamd), WEBHOOK par règle, SMS provider key. Tant que non configurés : mode réel = les notifications sont journalisées mais "delivery: pending-config" (jamais faux envoi).

## Pannes
- Cloche muette : le composant doit écouter `notifications-changed` ET `demo-world-pushed`.
- Webhook 403 : vérifier secret de signature dans la règle.
