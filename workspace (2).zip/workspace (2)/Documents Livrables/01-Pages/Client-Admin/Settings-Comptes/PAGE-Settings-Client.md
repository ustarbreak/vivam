# FICHE — Settings (client admin)

> Route : `#/settings` · Composant : `SettingsPage.tsx`

Onglets : Profil · Organisation · Sécurité (MFA TOTP, sessions) · Utilisateurs & rôles (Team & Roles) · Facturation/plane (Plans & Billing) · Notification channels.
⚠️ L'onglet **Demo Accounts est MASQUÉ pour client_admin** (visible seulement platform_admin/partner_admin). Ne pas le réafficher.
Endpoints : `/api/settings/*`, `/auth/mfa/*`, `/api/users/*` (RBAC serveur : un client_admin ne peut toucher qu'à son org_id).
