# FICHES PAGES COMPLÉMENTAIRES (D5) — Notifications, Automation, Settings, Platform Admin, Partner Portal

## A. Notification Center + Engine
**Routes** : cloche globale (Layout topbar → `src/components/NotificationBell.tsx`) · `/#/client-admin/notifications` (`NotificationEnginePage.tsx`)
| Action | Réel `/api` | Démo root `notifications` L411-443 / `notification-rules` L399-409 |
|---|---|---|
| Liste notifications | GET /notifications | store filtré org |
| Clic détail (dropdown cloche) | — (local) | corps, erreur webhook, canal, sévérité, ack |
| Acknowledge | POST /notifications/{id}/ack | L437 |
| Retry dead letters | POST /notifications/retry-failed OU /retry-dead-letters | L420/L432 : dead_letter→queued |
| Analytics délivrabilité | GET /notifications/analytics | L425 |
| Règles CRUD | GET/POST/PATCH/DELETE /notification-rules | L400-409 ; une règle matchant une alerte crée ticket+notif (auto_ticketing setting) |
**Modifier** : texte bouton "Retry failed" → grep dans NotificationBell.tsx ; canaux disponibles (email/sms/webhook) → constante channels en tête de NotificationEnginePage + backend channels_router ; déclenchement des règles → moteur démo bloc `alerts` POST L363-386 (cohérent avec auto-ticketing).
**Tests** : créer règle P1→email → pousser alerte critique via AlertsPage → badge cloche +1 → ouvrir détail → ack → retry sur une dead letter simulée.

## B. Automation ▸ Playbooks / Scripts AI / Runbooks
**Routes** : `/#/client-admin/playbooks` (`CustomPlaybooksLibrary.tsx`) · `/automation/scripts` (`AutomationScriptsPage.tsx`) · `/automation/runbooks` (`AutomationRunbooksPage.tsx`)
| Action | Réel `/api` | Démo |
|---|---|---|
| Playbooks CRUD | GET/POST/PUT/DELETE /playbooks | demoMode L445-451 |
| Exécuter un playbook | POST /playbooks/{id}/run | L452 : crée run + tickets/notifs selon actions |
| Générer script/playbook par IA | POST /playbooks/generate | côté démo : templates locaux (⚠️ réel = brancher LLM Phase IA) |
| Nouveau Runbook (bouton violet header) | POST /projects?runbook=true | modale : titre, projet lié, phase, doc collé |
| Auto-generate from doc IT | idem, body `{doc}` | L498-508 : 1 ligne = 1 step, max 10, estimation minutes |
**Modifier** : libellés boutons New Runbook/Auto-generate → grep AutomationRunbooksPage.tsx ; logique parsing doc→steps → fonction de split dans le handler + miroir demoMode L499 ; ajouter un type d'action playbook → enum actions en tête CustomPlaybooksLibrary + exécuteur démo L452 + moteur backend playbooks.

## C. Settings (carrefour des rôles)
**Route** : `/#/settings` (`src/pages/SettingsPage.tsx`) — onglets conditionnels (L103-109) :
| Onglet | Visible si | Backend |
|---|---|---|
| Demo Accounts | platform_admin \|\| partner_admin SEULEMENT (L103) | POST /seed-demo-tenant `_require_platform_admin` |
| Profile / Organization / Security (2FA) | tous | auth.py mfa_router |
| Automation / Platform | platform_admin | PUT /settings/system (toggles L13-18 : auto_ticketing, sla_escalations, email/sms/webhook, quiet_hours) |
| Notifications | tous | notification-rules |
| Branding & Domain / Licensing & Usage / Password Manager | partner_admin (centralisation demandée) | à porter en réel (password-reset-email écart E3) |
**Ajouter un toggle système** : tableau `toggleDefs` L12-18 + interface SystemSettings + PUT /settings/system backend + lecture par les workers.

## D. Platform Admin (résumé fiches détaillées à produire section par section)
| Page | Route | Composant | Point d'attention dev |
|---|---|---|---|
| Dashboard | /admin/dashboard | PlatformDashboardPage | consomme /settings/overview (compteurs globaux) |
| Tenant Manager | /admin/clients | PlatformClientsPage | CRUD organizations ; member_count/asset_count calculés depuis demoWorld en démo |
| Partner Program | /admin/partners | PlatformPartnersPage | ⚠️ /partners = démo only (écart G) |
| Audit Log | /admin/audit | PlatformAuditPage | GET /logs global vs /logs/my-org client |
| Services Ops | /admin/services-ops | PlatformServicesOverviewPage | état des connecteurs 16 services |
| Seed demo accounts | dans /settings | SettingsPage | génère comptes marocains cohérents |

## E. Partner Portal (6 pages, `src/pages/partner/PartnerPortalPages.tsx`)
| Page | Route | API | Logique clé |
|---|---|---|---|
| Dashboard | /partner/dashboard | /partners/stats 🅓 | KPI portefeuille + NRR/CSAT/churn sparkline MRR |
| My Clients | /partner/clients | /organizations?partner_id | provisionnement end-client sous marque partenaire, enforcement limites licence |
| Value & Loyalty | /partner/value | scorecard pondéré 30/25/15/15/15 % | paliers Silver/Gold/Platinum déterministes |
| Licensing & Usage | /partner/licensing | grille wholesale | calcul HT transparent sièges×prix×remise, zéro frais cachés |
| Branding & Domain | /partner/branding | PATCH branding | logo/couleur/CNAME + vérif DNS |
| Team Training | /partner/training | POST /api/partner/training/sessions 🅓 | planif lab Teams/Zoom/Meet + liens join |
**Modifier** : tous ces écrans sont dans UN fichier (~pages exportées nommées) — repérer l'export concerné avant édition ; grilles de prix → constante PRICE_TABLE en tête du fichier (source unique pour offers commerciaux).
