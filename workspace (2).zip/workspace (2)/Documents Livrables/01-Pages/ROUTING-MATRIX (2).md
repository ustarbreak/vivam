# ROUTING-MATRIX — Inventaire exhaustif routes → composants → endpoints (D6)
> Généré par analyse réelle du code (`src/App.tsx`, `src/components/Layout.tsx`, `src/services/demoMode.ts`, `backend/app/routers/*.py`). Version : 2026-10-22. Stack HashRouter (URLs `/#/…`).

## Légende
- **Démo** = intercepté par `demoMode.handle()` (root indiqué) quand `localStorage.ic_demo_mode==='1'`.
- **API** = endpoint réel FastAPI monté sous `/api` (préfixe global dans `backend/app/main.py`).

## A. Routes publiques (sans auth)
| Route hash | Composant | Fichier | Notes |
|---|---|---|---|
| `/` | LandingPage | `src/pages/LandingPage.tsx` (+ `src/pages/landing/*`) | Sections ancrées : #about #clients #partners #mssp #pricing |
| `/login` | LoginPage ou DemoAutoEnter | `src/pages/LoginPage.tsx` | Si `ic_fast_demo='1'` ou `VITE_FAST_DEMO=true` → bypass direct démo |
| `/demo` | DemoAutoEnter | `src/App.tsx` L74-95 | Active démo + login client-admin-enterprise ; garde stricte : jamais le backend réel |
| `/service/:serviceId` | ServiceDetailPage | `src/pages/ServiceDetailPage.tsx` | Fiche commerciale service |
| `/coming-soon/:serviceId` | ComingSoonPage | `src/pages/ComingSoonPage.tsx` | Teasing |
| `*` (catch-all) | Navigate `/` | `src/App.tsx` | Redirige vers landing |

## B. Client user (`role=client_user`)
| Route | Composant | API réelle | Démo root |
|---|---|---|---|
| `/dashboard` | DashboardPage | GET /alerts | alerts |
| `/threats` | ThreatsPage | GET /threats, /lookup/{ioc} | threat-intel |
| `/compliance` | CompliancePage | /services/{id}/live | services |
| `/incidents` | IncidentsPage | TheHive connector | services |
| `/analytics` | AnalyticsPage | Grafana connector | services |
| `/network` | NetworkPage | Netdata/LibreNMS | services |
| `/psa` | PSAPage | patch-management | services |

## C. Platform admin (`role=platform_admin`) — sidebar Layout.tsx L183-201
| Route | Label UI | Composant | API réelle | Démo root |
|---|---|---|---|---|
| `/admin/dashboard` | Dashboard | PlatformDashboardPage | GET /settings/overview | settings |
| `/admin/clients` | Tenant Manager | PlatformClientsPage | CRUD /organizations | organizations |
| `/admin/partners` | Partner Program | PlatformPartnersPage | ⚠️ GET /partners (démo only, voir §G) | partners |
| `/admin/audit` | Audit Log | PlatformAuditPage | GET /logs | audit |
| `/admin/services-ops` | Ticketing & Alerts Ops | PlatformServicesOverviewPage | GET /tickets/ops/workload | tickets |
| `/projects` | Project Manager | ProjectsPage | CRUD /projects (kind=internal forcé pour platform_admin) | projects |
| `/client-admin/advanced-tickets` | Service Desk | AdvancedTicketingPage | CRUD /tickets + evidence/audit/approvals | tickets |
| `/client-admin/notifications` | Notifications | NotificationEnginePage | /notification-rules, /notifications | notification-rules, notifications |
| `/client-admin/playbooks` | Automation ▸ Playbooks | CustomPlaybooksLibrary | CRUD /playbooks + POST /{id}/run | playbooks |
| `/client-admin/automation/scripts` | Automation ▸ Scripts AI | AutomationScriptsPage | POST /playbooks/generate | playbooks |
| `/client-admin/automation/runbooks` | Automation ▸ Runbooks | AutomationRunbooksPage | POST /projects?runbook=true + /projects/runbooks-from-doc | projects |
| `/settings` | Settings | SettingsPage | /settings/system, /seed-demo-tenant | settings |

## D. Client admin (`role=client_admin`) — sidebar Layout.tsx L232-273
### D1. Dashboard & Intelligence
| Route | Label UI | Composant | API | Démo |
|---|---|---|---|---|
| `/client-admin/dashboard` | Dashboard (fusion Overview+Value&Loyalty) | ClientAdminDashboardPage | GET /value/receipt, /value/proof-pack | value |
| `/client-admin/alerts` (+`/:alertId`) | Active Incidents | AlertsPage | GET/POST /alerts, POST /alerts/{id}/ack | alerts |
| `/client-admin/statistics` | Performance Metrics | StatisticsPage | — | computeDemoStats() |
| `/client-admin/notifications` | Notifications | NotificationEnginePage | idem §C | notifications |

### D2. Dropdown « Incidents & Statistics » (hover-expand)
| Route | Sous-item | Composant | API |
|---|---|---|---|
| `/client-admin/security-history` | Security History | SecurityHistoryTimeline | GET /logs/my-org |
| `/client-admin/statistics` | Statistics | StatisticsPage | — |
| `/client-admin/statistics/devices` | Devices | DeviceStatistics | dérivé demoWorld (24 devices) |
| `/client-admin/statistics/network` | Network Statistics | NetworkStatistics | /api/network/devices |
| `/client-admin/statistics/performance` | System Performance | PerformanceStatistics | /api/performance/metrics |
| `/client-admin/compliance-reports` | Compliance | ComplianceReports | gating entitlements |

### D3. Infrastructure & Services (pages de service)
| Route | Composant | Connecteur OSS interne (jamais visible client) |
|---|---|---|
| `/client-admin/infrastructure` | ClientAdminDashboard (Topology Visualizer) | LLDP/SNMP discovery |
| `/client-admin/monitored-devices` | MonitoredDevicesPage (Auto Discovery) | POST /scans, /snmp-credentials |
| `/client-admin/scan-history` | ScanHistoryPage | GET /scans, /scans/{id}/devices |
| `/client-admin/asset-inventory` | MonitoredAssetsPage (Monitored Devices + tenant/projet) | GET /devices, POST /devices/{id}/import |
| `/client-admin/email-security(/:alertId)` | EmailSecurityPage | Rspamd/Mailcow |
| `/client-admin/endpoint-protection(/:alertId)` | EndpointProtectionPage | Wazuh+ClamAV |
| `/client-admin/cloud-security(/:alertId)` | CloudSecurityPage | Prowler |
| `/client-admin/sd-wan(/:alertId)` | SDWANPage | NetBox |
| `/client-admin/vulnerability-scanning(/:vulnId)` | VulnerabilityScanningPage | OpenVAS |
| `/client-admin/patch-management` | PatchManagementPage | Fleet/osquery |
| `/client-admin/backup-dr` | BackupDRPage | Restic/Borgmatic |
| `/client-admin/soar` | SOARPage | n8n/Shuffle |
| `/client-admin/dns-filtering` | DNSFilteringPage | Pi-hole |
| `/client-admin/firewall-mgmt` | FirewallManagementPage | OPNsense |
| `/client-admin/vpn-gateway` | VPNGatewayPage | Tailscale |
| `/client-admin/architecture` | ArchitectureDiagram | masqué nav volontairement (voir §G) |
| `/client-admin/service/:serviceId/devices` | ServiceDeviceManager | entitlements |

### D4. Opérations & Delivery
| Route | Label UI | Composant | API |
|---|---|---|---|
| `/client-admin/advanced-tickets` | Service Desk | AdvancedTicketingPage | /tickets complet (notes, evidence fichiers, audit, approvals, closure-request) |
| `/projects` | Projects | ProjectsPage | /projects (kind=client), milestones, timer start/pause, attachments upload/download/delete, config PUT |
| `/reports` | Advanced Reporting | ReportsPage | /api/v1/reports*, export pdf/csv |
| `/client-admin/playbooks` | Playbooks | CustomPlaybooksLibrary | /playbooks |
| `/client-admin/automation/scripts` | Scripts AI | AutomationScriptsPage | /playbooks/generate |
| `/client-admin/automation/runbooks` | Runbooks | AutomationRunbooksPage | /projects?runbook |

### D5. Administration & Gouvernance
| Route | Label UI | Composant | API | Règle RBAC clé |
|---|---|---|---|---|
| `/client-admin/plans` | Subscription & Billing | ClientAdminPlans | /entitlements | — |
| `/client-admin/technicians` | Team & Roles | TechniciansManagementPage | /users | synchronisé demoTechnicians |
| `/client-admin/entitlements` | My Services | ClientEntitlementsPage | GET/POST/DELETE /entitlements | gating plan sur 16 services |
| `/settings` | Platform Configuration | SettingsPage | /settings/system | ❌ onglet Demo Accounts MASQUÉ pour client_admin (SettingsPage.tsx L103 : visible platform/partner admin seulement) |

## E. Partner portal (`role=partner_admin`) — sidebar L203-229
| Route | Label UI | Composant (PartnerPortalPages.tsx) | API |
|---|---|---|---|
| `/partner/dashboard` | {Brand} Dashboard | PartnerDashboardPage | /partners/stats (⚠️ démo only) |
| `/partner/clients` | My Clients | PartnerClientsPage | /organizations filtrées partner_id |
| `/client-admin/alerts` | Active Incidents | AlertsPage (réutilisé) | /alerts |
| `/client-admin/advanced-tickets` | Service Desk | AdvancedTicketingPage (réutilisé) | /tickets |
| `/client-admin/monitored-devices` etc. | Asset Inventory ▾ | réutilisation §D3 | discovery |
| `/reports` | Client Reports | ReportsPage | filtre tenant partenaire |
| `/projects` | Projects | ProjectsPage | kind=client |
| `/partner/value` | Value & Loyalty | PartnerValuePage | scorecard canal pondéré (30/25/15/15/15 %) |
| `/partner/licensing` | Licensing & Usage | PartnerLicensingPage | grille HT sièges×prix×remise |
| `/partner/branding` | Branding & Domain | PartnerBrandingPage | logo/couleurs/CNAME vérification |
| `/partner/training` | Team Training | PartnerTrainingPage | POST /api/partner/training/sessions (⚠️ démo only) |
| `/settings` | Settings | SettingsPage | tabs profil/2FA/branding/licensing/password-manager |

## F. Routes legacy (compatibilité — déjà en place App.tsx L214-222)
| Ancienne route | Redirection active |
|---|---|
| `/client-admin/tickets` | → `/client-admin/advanced-tickets` |
| `/client-admin/notification-engine` | → `/client-admin/notifications` |
| `/client-admin/custom-playbooks` | → `/client-admin/playbooks` |
| `/client-admin/value-and-loyalty` | → `/client-admin/dashboard` (fusion) |
| `/client-admin/overview` | → `/client-admin/dashboard` (fusion) |
| `/client-admin/device-statistics` | → `/client-admin/statistics/devices` |
| `/client-admin/network-statistics` | → `/client-admin/statistics/network` |
| `/client-admin/performance` | → `/client-admin/statistics/performance` |

## G. Écarts API détectés (démo ≠ réel) — à combler avant facturation
| Endpoint appelé par le front | Réel ? | Action requise |
|---|---|---|
| `GET /api/partners`, `/partners/stats` | ❌ aucun router partner monté dans main.py | Créer `backend/app/routers/partner.py` + models |
| `POST /api/partner/training/sessions` | ❌ | Idem (table training_sessions) |
| `POST /api/auth/password-reset-email` | ❌ (SMTP existe via notifications.py) | Brancher sur le module SMTP existant |
| `PUT /api/projects/{pid}/config` | partiel | Vérifier le champ config JSON dans models/projects.py |
| Nav "Integrations"/"Architecture" côté client | masquées volontairement | Pour les réafficher : ajouter l'entrée `{ to: '/client-admin/architecture', … }` dans servicesNav client_admin (Layout.tsx ~L286). Les routes restent actives, rien d'autre à toucher. |

## H. Command Palette (Ctrl+K / Cmd+K)
Index : `COMMAND_INDEX` dans `src/components/Layout.tsx` L95-117. Les aliases couvrent les anciens noms (taper "tickets" → Service Desk). Ajouter une entrée = pousser `{ label, aliases, to }` dans ce tableau.

## I. Boutons/liens morts audités (grep `href="#"` + `onClick={() => {}}`)
| Fichier:Ligne | Élément | Verdict | Recommandation |
|---|---|---|---|
| `LoginPage.tsx:238` | "Contact sales" | lien mort | → `mailto:sales@infracentra.ma` ou `/#pricing` |
| `LoginPage.tsx:331` | "Request access" | lien mort | → formulaire onboarding `/register` |
| `landing/PartnersSection.tsx:157,219` | CTA rejoindre programme | lien mort | → section `#mssp` (Find a Partner) |
| `landing/Footer.tsx:30` | API Docs | lien mort | créer page docs publique OU retirer le lien |
| `landing/Footer.tsx:36-39` | About/Careers/Blog/Contact | liens morts | About→`#about` ; Contact→`mailto:` ; Careers/Blog→retirer tant que vide |
| `landing/Footer.tsx:45-48` | Privacy/Terms/Security/SOC 2 | liens morts | créer `/#legal` (page légale) — requis pour ventes bancaires/santé |
Aucun bouton applicatif interne (sidebar, tableaux, modales) ne reste sans handler : tous résolus dans la matrice ci-dessus.
