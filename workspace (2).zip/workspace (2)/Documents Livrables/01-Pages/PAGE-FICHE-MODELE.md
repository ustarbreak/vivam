# MODÈLE DE FICHE PAGE (à copier pour chaque page documentée)

> Nom de la page : …
> Route hash : `#/…`
> Rôles autorisés : platform_admin / partner_admin / client_admin / technician / analyst
> Composant : `src/pages/…/XxxPage.tsx`
> Fiches liées : …

## 1. Identité & accès
| Élément | Valeur |
|---|---|
| Route | |
| Sidebar (parent/dropdown) | |
| RBAC (qui voit) | |
| Redirection ancienne route (compat) | |

## 2. Fonctionnalités (boutons/options)
| # | Élément UI | Handler (fonction) | Effet | Endpoint appelé (réel) | Intercepteur démo (`demoMode.ts`) |
|---|---|---|---|---|---|
| 1 | | | | | |

## 3. Données
- **Mode réel** : tables/columns source, endpoint, normalisation (`backend/app/services/...`).
- **Mode démo** : référence dans `src/data/demoWorld.ts` (devices/alertes/tickets/tenants concernés).
- Événements globaux écoutés/diffusés : `demo-world-pushed`, `notifications-changed`…

## 4. Comment modifier
- Changer un texte : ligne(s) `…`.
- Ajouter un bouton : pattern JSX à dupliquer + handler + (démo) case dans `demoMode.handle()`.
- Supprimer une option : retirer import/usage sans casser `…`.

## 5. Pannes typiques de cette page
| Symptôme | Cause | Fix |
|---|---|---|

## 6. Checklist non-régression après modif
- [ ] `npx tsc --noEmit` OK
- [ ] Mode démo : données cohérentes avec les autres pages (mêmes IDs/noms)
- [ ] Mode réel : badge "Donnée indisponible" si source absente (pas de zéro trompeur)
- [ ] RBAC : invisible pour les rôles non autorisés
- [ ] Build `npm run build` OK
