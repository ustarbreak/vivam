# INDEX — 01-Pages (documentation D5) & livrables D6/D8
| Fichier | Contenu | Prompt origine |
|---|---|---|
| `ROUTING-MATRIX.md` | Inventaire exhaustif routes→composants→endpoints, legacy redirects, boutons morts audités, écarts API démo/réel | **D6** |
| `FICHES-COMPLEMENTAIRES.md` | Notifications, Automation (Playbooks/Scripts/Runbooks), Settings, Platform Admin, Partner Portal | D5 |
| `Client-Admin/SERVICE-DESK-TICKETING.md` | Fiche complète Service Desk (evidence fichiers, approvals, SLA) | D5 |
| `Client-Admin/PROJECTS.md` | Fiche Projects (kind internal vs client, config ⚙️, attachments, runbooks auto-gen) | D5 |
| `Client-Admin/ASSET-INVENTORY.md` | Fiche Asset Inventory (3 sous-pages, matching SNMP, import→monitored) | D5 |

## Modèle de fiche à réutiliser pour les pages restantes (gabarit D5)
Chaque fiche doit contenir : ① Route + composant + rôles autorisés · ② Table endpoints (réel /api ↔ intercepteur démo avec ligne demoMode.ts) · ③ « Où modifier quoi » (texte bouton, ajout champ, colonne, statut…) · ④ Dépendances (contexts, événements globaux) · ⑤ Tests de non-régression numérotés incluant un test cross-tenant 403.

## Pages restant à documenter avec ce gabarit (priorité maintenance)
1. Dashboard fusionné (`client-admin/dashboard`) + Value engine 6 mécaniques
2. Alerts / Active Incidents
3. Advanced Reporting (20 rapports, filtre tenant)
4. Les 16 pages de service (une fiche générique suffit : même pattern connector + live feed)
5. Team & Roles / Subscription & Billing / Entitlements
6. Landing publique + Login (règle : jamais d'outils internes visibles)

Pour en générer une : ouvrir Claude Opus/GPT-5, coller `ARCHITECTURE-MAP.md`, puis le prompt **D5** de `PROMPTS.md` en précisant la section ciblée et en joignant le fichier `.tsx` concerné.
