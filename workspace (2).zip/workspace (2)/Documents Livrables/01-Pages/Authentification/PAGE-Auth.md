# FICHE — Login, MFA, Reset, Rôles

> Composants : `LoginPage.tsx`, `context/AuthContext.tsx` · Backend : router auth (JWT, bcrypt, TOTP).

- Toggle **Demo Mode** sur la page de login (persiste `localStorage.ic_demo_mode='1'`, installe auto le demoWorld). 6 boutons de connexion rapide : platform admin, client admin Damanecash (Pro+ticketing), Valoris System (Enterprise 16 svcs), Vivalis Salaf (SME sans ticketing), analyst, **Partner Admin (MSP)**.
- Emails *.ma tapés manuellement mappent vers le tenant démo correspondant.
- Réel : JWT claims {sub, role, org_id} ; org_id vient TOUJOURS du token (jamais d'un paramètre URL). MFA TOTP activable par user ; reset password par email (SMTP backend requis).
- Redirection post-login par rôle : platform_admin→/admin/dashboard · partner_admin→/partner/dashboard · client→/dashboard.
- Pannes : boucle de redirect = rôle inconnu dans la matrice ci-dessus ; session expirée → relogin propre (pas de crash).
