# Guide Portail Partenaire MSP (placeholder — PROMPT D3)

Pages couvertes : Dashboard · My Clients (provisioning end-clients sous marque partenaire) · Licensing & Usage (calcul HT transparent sièges×prix×remise, zéro frais caché) · Branding & Domain (logo, couleur, CNAME + vérification DNS) · Team & Training (modules + sessions live Teams/Zoom/Meet) · Value & Loyalty (scorecard canal, paliers Silver/Gold/Platinum, récompenses) · Settings (profil, 2FA, password manager/reset email).
Promesse programme : Infracentra garantit maintenance + formation des équipes ; le partenaire vend et manage ses clients sous son label.
