# Déploiement chez le client sans déplacement (placeholder — PROMPT D10)

Méthode : clé USB autoinstall Ubuntu + Docker → collector léger → enrollment one-time key vers la plateforme (HTTPS sortant seul, aucun port entrant à ouvrir chez le client) → configuration SNMP v3 des équipements → validation remontée → activation des services achetés depuis Platform Admin → checklist de livraison signée.
Versions équipe interne : Kali (start-kali.sh) et Windows (start-fullstack.bat).
