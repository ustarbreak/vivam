# DOCUMENTS LIVRABLES — INFRAvx / Infracentra (v2026.10-3)

Arborescence de documentation officielle. Chaque dossier est autonome : on y trouve la doc complète
de la page/sujet concerné + tout ce qui y est lié (code, routes, endpoints, démo, pannes, modifs).

## Schéma général

```
Documents Livrables/
├── 00-LISEZ-MOI.md                        ← ce fichier (index + conventions)
├── 01-Pages/                              ← DOC TECHNIQUE "page par page" (dev + owner)
│   ├── Client-Admin/                      (portail client : admin@damanecash.ma…)
│   │   ├── Dashboard-et-Overview/         Executive Dashboard fusionné + Value & Loyalty
│   │   ├── Ticketing/                     Service Desk, SLA, pièces jointes, édition
│   │   ├── Alerts-Incidents/              Alerts, Incidents, Security History, Statistiques
│   │   ├── Notifications/                 Moteur Email/SMS/Webhook + cloche
│   │   ├── Automation-Playbooks-Scripts-Runbooks/
│   │   ├── Asset-Inventory/               Auto Discovery / Scan History / Monitored Devices
│   │   ├── Reseau-Securite-perimetrique/  Network, Firewall, VPN, SD-WAN, DNS
│   │   ├── SOC-services/                  Les 16 services (pages produit)
│   │   ├── Conformite-Analytics/          Compliance Reports, Analytics
│   │   ├── Projets/                       Project Manager côté client
│   │   └── Settings-Comptes/              Paramètres client (sans comptes démo)
│   ├── Platform-Admin/                    Portail owner : tenants, partners, seed, audit…
│   ├── Reporting-Avance/                  20 rapports / 62 pages, exports, filtre tenant
│   ├── Authentification/                  Login, MFA TOTP, reset password, RBAC
│   └── Landing-Publique/                  Site vitrine (composants marketing)
├── 02-Doc-Publique/                        Brochure solution, pricing, FAQ prospects
├── 03-Doc-Clients-Utilisateurs/            Guides onboarding & manuels opérationnels clients
├── 04-Doc-Partenaires-MSP/                 Guide portail partenaire, white-label, licensing
├── 05-Doc-Securite-Conformite/             Dossier RSSI, matrice RBAC, politique rétention
├── 06-Doc-Technique-Integrations/          Playbook d'intégration par catégorie (anonymisé)
├── 07-Maintenance-Troubleshooting/         Pannes courantes symptom→fix, logs, backups
└── 08-Process-Deploiement/                 Installation distante sans déplacement, Kali/Windows
```

## Conventions (obligatoires pour toute fiche)

Chaque document technique d'une page suit le **modèle PAGE-FICHE.md** (voir 01-Pages/) :
1. **Identité** : route hash, rôle autorisé, composant source (chemin exact).
2. **Fonctionnalités** : liste exhaustive des boutons/options avec leur handler.
3. **API** : endpoints réels utilisés (méthode + payload) et intercepteur démo correspondant (`demoMode.ts`).
4. **Démo vs Réel** : origine des données dans les deux modes.
5. **Modifier** : où changer un texte, ajouter un bouton, supprimer une fonctionnalité sans casser les imports.
6. **Pannes** : erreurs typiques de cette page + fix.
7. **Tests** : checklist de non-régression après modification.

## Règles transverses rappelées partout
- **White-labeling** : aucun nom d'outil interne (MISP, Wazuh, TheHive, n8n, Netdata, Pi-hole, OPNsense…)
  ne doit apparaître dans 02, 03, 04, 05, 06. Catégories uniquement. Les noms vrais vivent dans `backend/app/services/connectors.py`.
- **Séparation démo/réel** : démo = `src/data/demoWorld.ts` (source unique), zéro réseau ; réel = FastAPI/PostgreSQL, jamais de faux zéros ("Donnée indisponible").
- **RBAC** : platform_admin ≠ client_admin ; le tenant vient du JWT, jamais d'un paramètre URL.
- **Cross-platform** : toutes procédures testables sur Kali ET Windows (start.bat / start-kali.sh).

## Comment rédiger/alimenter ces docs avec une IA
1. Fournir `ARCHITECTURE-MAP.md` (racine projet) comme contexte.
2. Utiliser les prompts de `PROMPTS.md` (D1→D10) — chaque prompt produit le contenu d'un dossier ci-dessus.
3. Coller le code de la page concernée en pièce jointe du prompt D5.
4. Ranger le livrable dans le dossier correspondant, nommer `PAGE-<Nom>.md`.

| Prompt | Remplit le dossier |
|---|---|
| D1 | 02-Doc-Publique |
| D2 | 03-Doc-Clients-Utilisateurs |
| D3 | 04-Doc-Partenaires-MSP |
| D4 | 07-Maintenance-Troubleshooting |
| D5 (x12 sections) | 01-Pages/** |
| D6 | 01-Pages/ROUTING-MATRIX.md |
| D7 | 05-Doc-Securite-Conformite |
| D8 | 05-Doc-Securite-Conformite/RBAC-MATRIX.md |
| D9 | 06-Doc-Technique-Integrations |
| D10 | 08-Process-Deploiement |
