# Playbook d'intégration par catégorie (placeholder — PROMPT D9, 12 fiches)

Pour chaque catégorie (EDR/XDR, supervision, renseignement menaces, gestion incidents, orchestration, sauvegarde, messagerie, cloud, réseau, pare-feu, DNS, accès distant) : prérequis réseau, credentials ({INTEGRATION_ENDPOINT}, {TOKEN} — variables génériques uniquement), ports sortants, temps d'onboarding, vérification badge LIVE FEED, cas d'échec + fallback.
Référence interne des vrais outils : `INTEGRATIONS-OSS.md` (racine) et `backend/app/services/connectors.py` — NE JAMAIS exporter ces noms en version cliente.
